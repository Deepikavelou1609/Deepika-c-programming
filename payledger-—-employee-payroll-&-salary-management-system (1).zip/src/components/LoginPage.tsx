import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Eye, EyeOff, Lock, User, UserPlus, ArrowRight, ArrowLeft } from 'lucide-react';

interface LoginPageProps {
  onLoginSuccess: (username: string, role: string) => void;
}

interface StoredUser {
  username: string;
  password: string;
  fullName: string;
  role: string;
}

const USERS_STORAGE_KEY = 'payledger_users_v1';

const DEFAULT_USERS: StoredUser[] = [
  { username: 'admin', password: 'admin123', fullName: 'Admin', role: 'Admin' },
  { username: 'hrstaff', password: 'payroll123', fullName: 'HR Staff', role: 'HR Staff' },
];

function loadUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // Fallback to defaults
  }
  return DEFAULT_USERS;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [fullName, setFullName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const switchMode = (nextMode: 'login' | 'register') => {
    setMode(nextMode);
    setError('');
    setSuccessMsg('');
    if (nextMode === 'register') {
      setFullName('');
      setUsername('');
      setPassword('');
      setConfirmPassword('');
    } else {
      setUsername('admin');
      setPassword('admin123');
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setError('Please enter both username and password.');
      return;
    }

    const users = loadUsers();
    const matched = users.find(
      (u) => u.username.toLowerCase() === cleanUser && u.password === cleanPass
    );

    if (!matched) {
      setError('Invalid username or password. Try admin / admin123 or register a new account.');
      return;
    }

    setIsSubmitting(true);
    window.setTimeout(() => {
      onLoginSuccess(matched.fullName || matched.username, matched.role);
    }, 280);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    const cleanName = fullName.trim();
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanName || !cleanUser || !cleanPass) {
      setError('Please fill in your name, username, and password.');
      return;
    }
    if (cleanPass.length < 4) {
      setError('Password must be at least 4 characters long.');
      return;
    }
    if (cleanPass !== confirmPassword.trim()) {
      setError('Passwords do not match.');
      return;
    }

    const users = loadUsers();
    if (users.some((u) => u.username.toLowerCase() === cleanUser)) {
      setError(`Username "${cleanUser}" is already registered.`);
      return;
    }

    const newUser: StoredUser = {
      username: cleanUser,
      password: cleanPass,
      fullName: cleanName,
      role: 'Payroll User',
    };

    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify([...users, newUser]));
    } catch {
      // Ignore storage errors
    }

    setIsSubmitting(true);
    setSuccessMsg('Account created! Signing you in...');
    window.setTimeout(() => {
      onLoginSuccess(newUser.fullName, newUser.role);
    }, 450);
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 sm:p-8 bg-gradient-to-br from-[#EAE8FF] via-[#F2F0FF] to-[#E2E0FE] overflow-hidden">
      {/* Delicate corner botanical leaves matching mockup */}
      <svg
        viewBox="0 0 220 180"
        className="pointer-events-none absolute -top-2 -left-2 w-48 sm:w-64 text-[#A7A3E8]/45"
        aria-hidden="true"
      >
        <path
          d="M0 130 C45 95, 95 65, 165 38"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
        />
        <path d="M40 100 C25 75, 42 52, 68 62 C62 84, 52 96, 40 100Z" fill="currentColor" opacity="0.65" />
        <path d="M52 96 C75 108, 92 94, 86 72 C68 78, 58 86, 52 96Z" fill="currentColor" opacity="0.45" />
        <path d="M92 68 C82 44, 102 26, 124 38 C118 58, 104 66, 92 68Z" fill="currentColor" opacity="0.7" />
        <path d="M104 64 C126 76, 144 64, 138 44 C120 48, 110 56, 104 64Z" fill="currentColor" opacity="0.5" />
        <path d="M148 44 C150 24, 174 16, 188 30 C176 44, 162 48, 148 44Z" fill="currentColor" opacity="0.6" />
      </svg>

      <svg
        viewBox="0 0 220 180"
        className="pointer-events-none absolute -bottom-2 -right-2 w-48 sm:w-64 text-[#A7A3E8]/45 rotate-180"
        aria-hidden="true"
      >
        <path
          d="M0 130 C45 95, 95 65, 165 38"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
        />
        <path d="M40 100 C25 75, 42 52, 68 62 C62 84, 52 96, 40 100Z" fill="currentColor" opacity="0.65" />
        <path d="M52 96 C75 108, 92 94, 86 72 C68 78, 58 86, 52 96Z" fill="currentColor" opacity="0.45" />
        <path d="M92 68 C82 44, 102 26, 124 38 C118 58, 104 66, 92 68Z" fill="currentColor" opacity="0.7" />
        <path d="M104 64 C126 76, 144 64, 138 44 C120 48, 110 56, 104 64Z" fill="currentColor" opacity="0.5" />
        <path d="M148 44 C150 24, 174 16, 188 30 C176 44, 162 48, 148 44Z" fill="currentColor" opacity="0.6" />
      </svg>

      {/* Centered Split Login Card */}
      <motion.div
        initial={{ opacity: 0, y: 18, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-4xl rounded-3xl bg-white shadow-[0_24px_70px_-18px_rgba(78,70,180,0.22)] border border-[#E2E0FA] overflow-hidden grid grid-cols-1 md:grid-cols-12"
      >
        {/* Left Lavender Illustration Panel */}
        <div className="md:col-span-6 bg-gradient-to-b from-[#E5E3FC] via-[#DFDCFB] to-[#D7D4F9] px-8 py-9 flex flex-col items-center justify-between text-center relative">
          {/* Top Brand Emblem + Title */}
          <div className="w-full space-y-3">
            <div className="mx-auto w-20 h-14 flex items-center justify-center">
              <svg viewBox="0 0 80 56" className="w-20 h-14" aria-hidden="true">
                {/* People cluster */}
                <circle cx="38" cy="16" r="7.5" fill="#2A2866" />
                <path d="M22 40c0-8 7-13 16-13s16 5 16 13v3H22v-3z" fill="#2A2866" />
                <circle cx="20" cy="21" r="5" fill="#2A2866" />
                <path d="M9 40c0-5.5 4.5-9.5 10-9.8-1.8 2.4-2.8 5.8-2.8 9.8v3H9v-3z" fill="#2A2866" />
                <circle cx="56" cy="21" r="5" fill="#2A2866" />
                {/* Coin stack badge */}
                <ellipse cx="58" cy="34" rx="8.5" ry="3.2" fill="#E5E3FC" stroke="#2A2866" strokeWidth="2.2" />
                <path d="M49.5 34v5c0 1.8 3.8 3.2 8.5 3.2s8.5-1.4 8.5-3.2v-5" fill="#2A2866" />
                <ellipse cx="58" cy="34" rx="8.5" ry="3.2" fill="#2A2866" stroke="#E5E3FC" strokeWidth="1.5" />
                <path d="M49.5 40v5c0 1.8 3.8 3.2 8.5 3.2s8.5-1.4 8.5-3.2v-5" fill="#2A2866" stroke="#E5E3FC" strokeWidth="1.4" />
              </svg>
            </div>

            <h1 className="text-2xl font-bold text-[#25235C] leading-snug tracking-tight">
              Employee Payroll &amp;
              <br />
              Salary Management System
            </h1>

            <div className="flex items-center justify-center gap-3 pt-1">
              <span className="h-px w-10 bg-[#8F8BD0]" />
              <span className="text-sm italic font-medium text-[#373472]">
                Manage · Calculate · Track
              </span>
              <span className="h-px w-10 bg-[#8F8BD0]" />
            </div>
          </div>

          {/* Bottom Payroll Illustration: Plant + Laptop with PAYROLL Sheet + Calculator + Gold Coins */}
          <div className="w-full max-w-[320px] mt-6">
            <svg viewBox="0 0 340 200" className="w-full h-auto" aria-hidden="true">
              {/* Soft ground oval */}
              <ellipse cx="170" cy="178" rx="145" ry="14" fill="#C4BFF5" opacity="0.6" />

              {/* Potted Plant */}
              <path d="M38 134h34l-5 40H43l-5-40z" fill="#B5B2DB" />
              <rect x="34" y="128" width="42" height="8" rx="3" fill="#9E9ACB" />
              <path d="M55 128V78" stroke="#538D6B" strokeWidth="3" strokeLinecap="round" />
              <path d="M55 104c-16-4-24-16-22-30 14 2 24 12 22 30z" fill="#639F7B" />
              <path d="M55 96c16-4 24-18 22-32-14 2-24 14-22 32z" fill="#77B890" />
              <path d="M55 118c-13-2-20-11-19-21 12 2 19 9 19 21z" fill="#7FC198" />
              <path d="M55 114c14-2 21-11 20-21-12 2-20 9-20 21z" fill="#5B9472" />

              {/* Laptop Back & Base */}
              <rect x="108" y="42" width="128" height="114" rx="10" fill="#3B3A6E" />
              <rect x="115" y="49" width="114" height="100" rx="6" fill="#52508C" />
              <path d="M84 156h156l8 12c2 3 0 6-4 6H80c-4 0-6-3-4-6l8-12z" fill="#5D5B99" />

              {/* Rising PAYROLL Document Card */}
              <g transform="rotate(-4 168 95)">
                <rect x="122" y="24" width="92" height="122" rx="8" fill="#FFFFFF" stroke="#D7D5F8" strokeWidth="2" />
                <text
                  x="168"
                  y="46"
                  textAnchor="middle"
                  fill="#33306E"
                  fontSize="13"
                  fontWeight="700"
                  fontFamily="sans-serif"
                >
                  PAYROLL
                </text>
                <line x1="136" y1="54" x2="200" y2="54" stroke="#E4E2FC" strokeWidth="2" />
                {/* Checkmarks & lines */}
                <path d="M134 72l4 4 7-8" stroke="#6B65D8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                <rect x="150" y="68" width="46" height="5" rx="2.5" fill="#C9C6F8" />
                <rect x="150" y="77" width="32" height="4" rx="2" fill="#E3E1FB" />

                <path d="M134 98l4 4 7-8" stroke="#6B65D8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                <rect x="150" y="94" width="46" height="5" rx="2.5" fill="#C9C6F8" />
                <rect x="150" y="103" width="36" height="4" rx="2" fill="#E3E1FB" />

                <rect x="134" y="120" width="62" height="5" rx="2.5" fill="#E3E1FB" />
              </g>

              {/* Calculator */}
              <g transform="rotate(6 226 135)">
                <rect x="196" y="96" width="62" height="78" rx="9" fill="#3B3A6E" />
                <rect x="203" y="103" width="48" height="18" rx="4" fill="#D9D7F7" />
                <rect x="204" y="127" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="220" y="127" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="236" y="127" width="12" height="9" rx="2" fill="#F4B860" />
                <rect x="204" y="140" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="220" y="140" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="236" y="140" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="204" y="153" width="12" height="9" rx="2" fill="#8C89C4" />
                <rect x="220" y="153" width="28" height="9" rx="2" fill="#8C89C4" />
              </g>

              {/* Stacked Gold Coins */}
              <g>
                {/* Back stack */}
                <rect x="260" y="124" width="32" height="48" rx="5" fill="#E69E2E" />
                <ellipse cx="276" cy="124" rx="16" ry="5.5" fill="#FCD06B" stroke="#E69E2E" strokeWidth="1.5" />
                <line x1="260" y1="136" x2="292" y2="136" stroke="#D1881D" strokeWidth="1.5" />
                <line x1="260" y1="148" x2="292" y2="148" stroke="#D1881D" strokeWidth="1.5" />
                <line x1="260" y1="160" x2="292" y2="160" stroke="#D1881D" strokeWidth="1.5" />
                {/* Front right stack */}
                <rect x="284" y="144" width="30" height="30" rx="5" fill="#ECA736" />
                <ellipse cx="299" cy="144" rx="15" ry="5" fill="#FCD06B" stroke="#E69E2E" strokeWidth="1.5" />
                <line x1="284" y1="154" x2="314" y2="154" stroke="#D1881D" strokeWidth="1.5" />
                <line x1="284" y1="164" x2="314" y2="164" stroke="#D1881D" strokeWidth="1.5" />
              </g>
            </svg>
          </div>
        </div>

        {/* Right Clean White Form Panel */}
        <div className="md:col-span-6 bg-white px-8 py-10 sm:px-12 flex flex-col justify-center">
          <AnimatePresence mode="wait">
            {mode === 'login' ? (
              <motion.div
                key="login-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="w-full max-w-sm mx-auto"
              >
                <div className="text-center mb-7">
                  <h2 className="text-3xl font-bold text-[#25235C] tracking-tight">Login</h2>
                  <p className="text-sm text-[#4A477A] mt-1.5">Access your account</p>
                  <div className="mx-auto mt-2.5 h-0.5 w-14 rounded-full bg-[#DCD9FA]" />
                </div>

                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-medium text-rose-700"
                    >
                      {error}
                    </motion.div>
                  )}

                  <div className="relative">
                    <User className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Username"
                      aria-label="Username"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-4 py-3 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                  </div>

                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Password"
                      aria-label="Password"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-11 py-3 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#5A578A] hover:text-[#25235C] p-1"
                    >
                      {showPassword ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                  </div>

                  <motion.button
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.985 }}
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full mt-1 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6059C9] to-[#4E46B8] px-5 py-3 text-sm font-semibold text-white shadow-md shadow-indigo-500/20 hover:from-[#544DC0] hover:to-[#433BAE] transition-all disabled:opacity-70"
                  >
                    <span>{isSubmitting ? 'Signing in...' : 'Login'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </form>

                <div className="flex items-center gap-3 my-5">
                  <span className="h-px flex-1 bg-[#E5E3FA]" />
                  <span className="text-xs font-medium text-[#5A578A]">or</span>
                  <span className="h-px flex-1 bg-[#E5E3FA]" />
                </div>

                <motion.button
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.985 }}
                  type="button"
                  onClick={() => switchMode('register')}
                  className="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-[#8E89D4] bg-white px-5 py-2.5 text-sm font-semibold text-[#25235C] hover:bg-[#F5F4FF] transition-colors"
                >
                  <UserPlus className="w-4 h-4 text-[#4E46B8]" />
                  <span>New User? Register</span>
                </motion.button>

                <div className="mt-6 flex flex-col items-center gap-1 text-xs text-[#5A578A]">
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#5A578A]" />
                    Secure &amp; Confidential
                  </span>
                  <span className="text-[11px] text-[#7D7AA8]">
                    Demo: <span className="font-mono text-[#4E46B8]">admin / admin123</span>
                  </span>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="register-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="w-full max-w-sm mx-auto"
              >
                <div className="text-center mb-6">
                  <h2 className="text-3xl font-bold text-[#25235C] tracking-tight">Register</h2>
                  <p className="text-sm text-[#4A477A] mt-1.5">Create a payroll account</p>
                  <div className="mx-auto mt-2.5 h-0.5 w-14 rounded-full bg-[#DCD9FA]" />
                </div>

                <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-medium text-rose-700"
                    >
                      {error}
                    </motion.div>
                  )}

                  {successMsg && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-xl bg-emerald-50 border border-emerald-200 px-3.5 py-2.5 text-xs font-medium text-emerald-700"
                    >
                      {successMsg}
                    </motion.div>
                  )}

                  <div className="relative">
                    <User className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Full Name"
                      aria-label="Full Name"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-4 py-2.5 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                  </div>

                  <div className="relative">
                    <User className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Choose Username"
                      aria-label="Choose Username"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-4 py-2.5 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                  </div>

                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Create Password"
                      aria-label="Create Password"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-11 py-2.5 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#5A578A] hover:text-[#25235C] p-1"
                    >
                      {showPassword ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#5A578A] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm Password"
                      aria-label="Confirm Password"
                      className="w-full rounded-xl border border-[#C6C3EE] bg-white pl-11 pr-4 py-2.5 text-sm text-[#25235C] placeholder:text-[#7875A6] focus:border-[#5D57C8] focus:ring-2 focus:ring-[#5D57C8]/15 focus:outline-none transition-all"
                    />
                  </div>

                  <motion.button
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.985 }}
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6059C9] to-[#4E46B8] px-5 py-3 text-sm font-semibold text-white shadow-md shadow-indigo-500/20 hover:from-[#544DC0] hover:to-[#433BAE] transition-all disabled:opacity-70"
                  >
                    <span>{isSubmitting ? 'Creating Account...' : 'Create Account'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </form>

                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="w-full mt-4 inline-flex items-center justify-center gap-2 rounded-xl border border-[#8E89D4] bg-white px-5 py-2.5 text-sm font-semibold text-[#25235C] hover:bg-[#F5F4FF] transition-colors"
                >
                  <ArrowLeft className="w-4 h-4 text-[#4E46B8]" />
                  <span>Back to Login</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
