import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Calculator } from 'lucide-react';
import { DEPARTMENTS, Department, Employee, PaymentStatus } from '../types/payroll';
import {
  calculateAllowances,
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  computeStandardComponents,
  formatINR,
} from '../utils/payrollCalc';

interface EmployeeModalProps {
  isOpen: boolean;
  mode: 'add' | 'edit';
  initialEmployee: Employee | null;
  existingIds: string[];
  onClose: () => void;
  onSave: (employee: Employee) => void;
}

export const EmployeeModal: React.FC<EmployeeModalProps> = ({
  isOpen,
  mode,
  initialEmployee,
  existingIds,
  onClose,
  onSave,
}) => {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [department, setDepartment] = useState<Department>('CSE Cyber Security');
  const [designation, setDesignation] = useState('');
  const [email, setEmail] = useState('');
  const [joinDate, setJoinDate] = useState('2026-01-15');
  const [bankAccountLast4, setBankAccountLast4] = useState('1234');
  const [basicSalary, setBasicSalary] = useState('25000');
  const [hra, setHra] = useState('3000');
  const [da, setDa] = useState('1500');
  const [otherAllowances, setOtherAllowances] = useState('500');
  const [pfDeduction, setPfDeduction] = useState('1500');
  const [taxDeduction, setTaxDeduction] = useState('300');
  const [otherDeductions, setOtherDeductions] = useState('200');
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Pending');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setError('');
    if (mode === 'edit' && initialEmployee) {
      setId(initialEmployee.id);
      setName(initialEmployee.name);
      setDepartment(initialEmployee.department);
      setDesignation(initialEmployee.designation);
      setEmail(initialEmployee.email);
      setJoinDate(initialEmployee.joinDate);
      setBankAccountLast4(initialEmployee.bankAccountLast4);
      setBasicSalary(String(initialEmployee.basicSalary));
      setHra(String(initialEmployee.hra));
      setDa(String(initialEmployee.da));
      setOtherAllowances(String(initialEmployee.otherAllowances));
      setPfDeduction(String(initialEmployee.pfDeduction));
      setTaxDeduction(String(initialEmployee.taxDeduction));
      setOtherDeductions(String(initialEmployee.otherDeductions));
      setPaymentStatus(initialEmployee.paymentStatus);
    } else {
      const numericParts = existingIds
        .map((val) => parseInt(val.replace(/\D/g, ''), 10))
        .filter((n) => !Number.isNaN(n));
      const nextNum = numericParts.length > 0 ? Math.max(...numericParts) + 1 : 1;
      const nextId = `E${String(nextNum).padStart(3, '0')}`;
      const defaultBasic = 28000;
      const std = computeStandardComponents(defaultBasic);
      setId(nextId);
      setName('');
      setDepartment('CSE Cyber Security');
      setDesignation('Software Engineer');
      setEmail('');
      setJoinDate(new Date().toISOString().slice(0, 10));
      setBankAccountLast4(String(1000 + Math.floor(Math.random() * 8999)));
      setBasicSalary(String(defaultBasic));
      setHra(String(std.hra));
      setDa(String(std.da));
      setOtherAllowances(String(std.otherAllowances));
      setPfDeduction(String(std.pfDeduction));
      setTaxDeduction(String(std.taxDeduction));
      setOtherDeductions(String(std.otherDeductions));
      setPaymentStatus('Pending');
    }
  }, [isOpen, mode, initialEmployee, existingIds]);

  if (!isOpen) return null;

  const num = (val: string) => Math.max(0, Number(val) || 0);

  const previewRecord = {
    basicSalary: num(basicSalary),
    hra: num(hra),
    da: num(da),
    otherAllowances: num(otherAllowances),
    pfDeduction: num(pfDeduction),
    taxDeduction: num(taxDeduction),
    otherDeductions: num(otherDeductions),
  };

  const previewAllowances = calculateAllowances(previewRecord);
  const previewGross = calculateGrossSalary(previewRecord);
  const previewDeductions = calculateDeductions(previewRecord);
  const previewNet = calculateNetSalary(previewRecord);

  const handleAutoCalculate = () => {
    const basic = num(basicSalary);
    const std = computeStandardComponents(basic);
    setHra(String(std.hra));
    setDa(String(std.da));
    setOtherAllowances(String(std.otherAllowances));
    setPfDeduction(String(std.pfDeduction));
    setTaxDeduction(String(std.taxDeduction));
    setOtherDeductions(String(std.otherDeductions));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedId = id.trim();
    const trimmedName = name.trim();
    const trimmedDesignation = designation.trim();

    if (!trimmedId) {
      setError('Employee ID is required.');
      return;
    }
    if (mode === 'add' && existingIds.includes(trimmedId)) {
      setError(`Employee ID "${trimmedId}" already exists.`);
      return;
    }
    if (!trimmedName) {
      setError('Employee full name is required.');
      return;
    }
    if (!trimmedDesignation) {
      setError('Designation is required.');
      return;
    }
    if (num(basicSalary) <= 0) {
      setError('Basic salary must be greater than zero.');
      return;
    }

    const cleanLast4 = bankAccountLast4.replace(/\D/g, '').slice(-4).padStart(4, '0');

    onSave({
      id: trimmedId,
      name: trimmedName,
      department,
      designation: trimmedDesignation,
      email:
        email.trim() ||
        `${trimmedName.toLowerCase().replace(/[^a-z0-9]+/g, '.')}@payroll.edu.in`,
      joinDate: joinDate || new Date().toISOString().slice(0, 10),
      basicSalary: previewRecord.basicSalary,
      hra: previewRecord.hra,
      da: previewRecord.da,
      otherAllowances: previewRecord.otherAllowances,
      pfDeduction: previewRecord.pfDeduction,
      taxDeduction: previewRecord.taxDeduction,
      otherDeductions: previewRecord.otherDeductions,
      paymentStatus,
      lastPaidMonth: paymentStatus === 'Paid' ? '2026-11' : initialEmployee?.lastPaidMonth || '2026-10',
      bankAccountLast4: cleanLast4,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1E1B4B]/40 backdrop-blur-xs p-4 overflow-y-auto no-print"
      role="dialog"
      aria-modal="true"
      aria-labelledby="employee-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-2xl rounded-2xl bg-white border border-[#DDDDFB] shadow-2xl overflow-hidden my-8"
      >
        <div className="flex items-center justify-between px-6 py-4 bg-[#F6F5FF] border-b border-[#E5E4FA]">
          <div>
            <h2 id="employee-modal-title" className="text-lg font-bold text-[#1E1B4B]">
              {mode === 'add' ? 'Add Employee Record' : `Edit Employee · ${id}`}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Module 1 · Employee record entry &amp; salary component structure
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-lg text-slate-400 hover:text-[#1E1B4B] hover:bg-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="emp-id" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Employee ID
              </label>
              <input
                id="emp-id"
                type="text"
                value={id}
                disabled={mode === 'edit'}
                onChange={(e) => setId(e.target.value)}
                placeholder="E006"
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] disabled:bg-slate-100 disabled:text-slate-500 focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="emp-name" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Full Name
              </label>
              <input
                id="emp-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Laksheka S A"
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="emp-dept" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Department
              </label>
              <select
                id="emp-dept"
                value={department}
                onChange={(e) => setDepartment(e.target.value as Department)}
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              >
                {DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="emp-desig" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Designation
              </label>
              <input
                id="emp-desig"
                type="text"
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                placeholder="e.g. Software Engineer"
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="emp-status" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Payroll Status
              </label>
              <select
                id="emp-status"
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              >
                <option value="Pending">Pending</option>
                <option value="Paid">Paid</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label htmlFor="emp-email" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Work Email (optional)
              </label>
              <input
                id="emp-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@payroll.edu.in"
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="emp-bank" className="block text-xs font-semibold text-[#1E1B4B] mb-1">
                Bank A/C (Last 4)
              </label>
              <input
                id="emp-bank"
                type="text"
                maxLength={4}
                value={bankAccountLast4}
                onChange={(e) => setBankAccountLast4(e.target.value)}
                placeholder="4821"
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-[#F0EFFE]">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h3 className="text-sm font-bold text-[#1E1B4B]">
                Salary Structure &amp; Deductions (INR)
              </h3>
              <button
                type="button"
                onClick={handleAutoCalculate}
                className="inline-flex items-center gap-1.5 rounded-xl border border-[#DDDDFB] bg-[#F4F3FF] px-3 py-1.5 text-xs font-semibold text-[#4F46E5] hover:bg-[#EAE8FF] transition-colors whitespace-nowrap shrink-0"
              >
                <Calculator className="w-3.5 h-3.5" />
                Auto-Calculate from Basic
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label htmlFor="emp-basic" className="block text-xs font-medium text-slate-700 mb-1">
                  Basic Salary
                </label>
                <input
                  id="emp-basic"
                  type="number"
                  min={0}
                  value={basicSalary}
                  onChange={(e) => setBasicSalary(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-hra" className="block text-xs font-medium text-slate-700 mb-1">
                  HRA
                </label>
                <input
                  id="emp-hra"
                  type="number"
                  min={0}
                  value={hra}
                  onChange={(e) => setHra(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-da" className="block text-xs font-medium text-slate-700 mb-1">
                  DA
                </label>
                <input
                  id="emp-da"
                  type="number"
                  min={0}
                  value={da}
                  onChange={(e) => setDa(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-other-all" className="block text-xs font-medium text-slate-700 mb-1">
                  Other Allowances
                </label>
                <input
                  id="emp-other-all"
                  type="number"
                  min={0}
                  value={otherAllowances}
                  onChange={(e) => setOtherAllowances(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-pf" className="block text-xs font-medium text-slate-700 mb-1">
                  PF Deduction
                </label>
                <input
                  id="emp-pf"
                  type="number"
                  min={0}
                  value={pfDeduction}
                  onChange={(e) => setPfDeduction(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-tax" className="block text-xs font-medium text-slate-700 mb-1">
                  Income Tax (TDS)
                </label>
                <input
                  id="emp-tax"
                  type="number"
                  min={0}
                  value={taxDeduction}
                  onChange={(e) => setTaxDeduction(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-other-ded" className="block text-xs font-medium text-slate-700 mb-1">
                  Prof. Tax / Other
                </label>
                <input
                  id="emp-other-ded"
                  type="number"
                  min={0}
                  value={otherDeductions}
                  onChange={(e) => setOtherDeductions(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="emp-join" className="block text-xs font-medium text-slate-700 mb-1">
                  Join Date
                </label>
                <input
                  id="emp-join"
                  type="date"
                  value={joinDate}
                  onChange={(e) => setJoinDate(e.target.value)}
                  className="w-full rounded-xl border border-[#DDDDFB] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-[#F4F3FF] border border-[#DFDDFA] px-4 py-3 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <p className="text-xs text-slate-500">Total Allowances</p>
              <p className="text-sm font-semibold font-mono tabular-nums text-[#1E1B4B] mt-0.5">
                {formatINR(previewAllowances)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Gross Salary</p>
              <p className="text-sm font-semibold font-mono tabular-nums text-[#1E1B4B] mt-0.5">
                {formatINR(previewGross)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Deductions</p>
              <p className="text-sm font-semibold font-mono tabular-nums text-rose-600 mt-0.5">
                -{formatINR(previewDeductions)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Net Payable</p>
              <p className="text-sm font-bold font-mono tabular-nums text-[#4F46E5] mt-0.5">
                {formatINR(previewNet)}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#F0EFFE]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-[#DDDDFB] bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-5 py-2 text-sm font-semibold text-white hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
            >
              {mode === 'add' ? 'Save Employee' : 'Update Record'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};
