import React from 'react';
import { motion } from 'motion/react';
import {
  Home,
  UserPlus,
  Users,
  Calculator,
  FileBarChart2,
  Settings,
  LogOut,
  X,
} from 'lucide-react';
import { NavSection } from '../types/payroll';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  onAddEmployee: () => void;
  onLogout: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  onAddEmployee,
  onLogout,
  mobileOpen,
  onCloseMobile,
}) => {
  const menuItems: Array<{
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    isActive: boolean;
    onClick: () => void;
  }> = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      isActive: activeSection === 'home',
      onClick: () => {
        onSelectSection('home');
        onCloseMobile();
      },
    },
    {
      id: 'add',
      label: 'Add Employee',
      icon: UserPlus,
      isActive: false,
      onClick: () => {
        onAddEmployee();
        onCloseMobile();
      },
    },
    {
      id: 'employees',
      label: 'View Employees',
      icon: Users,
      isActive: activeSection === 'employees',
      onClick: () => {
        onSelectSection('employees');
        onCloseMobile();
      },
    },
    {
      id: 'calculate',
      label: 'Calculate Salary',
      icon: Calculator,
      isActive: activeSection === 'calculate',
      onClick: () => {
        onSelectSection('calculate');
        onCloseMobile();
      },
    },
    {
      id: 'payroll',
      label: 'Payroll Report',
      icon: FileBarChart2,
      isActive: activeSection === 'payroll',
      onClick: () => {
        onSelectSection('payroll');
        onCloseMobile();
      },
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      isActive: activeSection === 'settings',
      onClick: () => {
        onSelectSection('settings');
        onCloseMobile();
      },
    },
  ];

  const navContent = (
    <div className="flex h-full flex-col justify-between bg-[#F7F6FF] border-r border-[#E4E3FA] px-4 py-6">
      <div>
        {/* Close button on mobile */}
        <div className="flex justify-end lg:hidden mb-2">
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation"
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#1E1B4B] hover:bg-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Brand Header matching pastel mockup */}
        <div className="flex flex-col items-center text-center pb-5 border-b border-[#E5E4FA]">
          <div className="w-16 h-12 flex items-center justify-center mb-2">
            <svg viewBox="0 0 64 48" className="w-14 h-11" aria-hidden="true">
              <circle cx="32" cy="15" r="7" fill="#6D67E4" />
              <path d="M18 37c0-7 6.3-11.5 14-11.5S46 30 46 37v3H18v-3z" fill="#6D67E4" />
              <circle cx="15" cy="19" r="5" fill="#9A95F5" />
              <path d="M5 37c0-4.8 4-8.3 9.2-8.7-1.7 2.2-2.7 5-2.7 8.7v3H5v-3z" fill="#9A95F5" />
              <circle cx="49" cy="19" r="5" fill="#9A95F5" />
              <path d="M59 37c0-4.8-4-8.3-9.2-8.7 1.7 2.2 2.7 5 2.7 8.7v3H59v-3z" fill="#9A95F5" />
            </svg>
          </div>
          <h2 className="text-sm font-bold text-[#1E1B4B] leading-snug px-2">
            Employee Payroll &amp; Salary Management System
          </h2>
        </div>

        {/* Navigation Links */}
        <nav className="mt-5 space-y-1.5" aria-label="Primary Navigation">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.id}
                type="button"
                whileHover={{ x: 2 }}
                whileTap={{ scale: 0.985 }}
                onClick={item.onClick}
                className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium rounded-xl transition-all whitespace-nowrap shrink-0 ${
                  item.isActive
                    ? 'bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] text-white shadow-sm shadow-indigo-500/20'
                    : 'text-[#2D2A5E] hover:bg-[#ECEBFF] hover:text-[#1E1B4B]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    item.isActive ? 'text-white' : 'text-[#3F3B78]'
                  }`}
                />
                <span>{item.label}</span>
              </motion.button>
            );
          })}

          <motion.button
            type="button"
            whileHover={{ x: 2 }}
            whileTap={{ scale: 0.985 }}
            onClick={() => {
              onCloseMobile();
              onLogout();
            }}
            className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium rounded-xl text-[#2D2A5E] hover:bg-rose-50 hover:text-rose-700 transition-all whitespace-nowrap shrink-0"
          >
            <LogOut className="w-4 h-4 shrink-0 text-[#3F3B78]" />
            <span>Exit</span>
          </motion.button>
        </nav>
      </div>

      {/* Bottom Accent Illustration */}
      <div className="pt-4 flex items-end gap-2 px-1">
        <svg viewBox="0 0 64 72" className="w-12 h-14 shrink-0" aria-hidden="true">
          <path d="M22 48h20l-3 18H25l-3-18z" fill="#D9D7F7" stroke="#A7A3EB" strokeWidth="1.5" />
          <path d="M32 48V24" stroke="#4D7C5F" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M32 34c-8-2-13-8-12-16 8 1 13 7 12 16z" fill="#77B890" />
          <path d="M32 30c9-2 14-9 13-17-8 1-14 8-13 17z" fill="#5CA378" />
          <path d="M32 42c-7-1-12-6-11-12 7 1 11 5 11 12z" fill="#89C9A1" />
        </svg>
        <div className="pb-1">
          <p className="text-xs font-semibold italic text-[#312E81] leading-tight">
            Work Smart,
            <br />
            Pay Fair
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-60 shrink-0 no-print">{navContent}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden no-print">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-50 w-64 h-full">{navContent}</aside>
        </div>
      )}
    </>
  );
};
