import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Calculator, CheckCircle2, ReceiptIndianRupee, Save } from 'lucide-react';
import { Employee } from '../types/payroll';
import {
  calculateAllowances,
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  computeStandardComponents,
  formatINR,
} from '../utils/payrollCalc';

interface CalculateSalaryViewProps {
  employees: Employee[];
  onUpdateEmployeeSalary: (updated: Employee) => void;
  onOpenPaySlip: (employee: Employee) => void;
}

export const CalculateSalaryView: React.FC<CalculateSalaryViewProps> = ({
  employees,
  onUpdateEmployeeSalary,
  onOpenPaySlip,
}) => {
  const [selectedId, setSelectedId] = useState<string>(employees[0]?.id || '');
  const selectedEmp = employees.find((e) => e.id === selectedId) || employees[0] || null;

  const [basicSalary, setBasicSalary] = useState('25000');
  const [hra, setHra] = useState('3000');
  const [da, setDa] = useState('1500');
  const [otherAllowances, setOtherAllowances] = useState('500');
  const [pfDeduction, setPfDeduction] = useState('1500');
  const [taxDeduction, setTaxDeduction] = useState('300');
  const [otherDeductions, setOtherDeductions] = useState('200');
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    if (!selectedEmp) return;
    setBasicSalary(String(selectedEmp.basicSalary));
    setHra(String(selectedEmp.hra));
    setDa(String(selectedEmp.da));
    setOtherAllowances(String(selectedEmp.otherAllowances));
    setPfDeduction(String(selectedEmp.pfDeduction));
    setTaxDeduction(String(selectedEmp.taxDeduction));
    setOtherDeductions(String(selectedEmp.otherDeductions));
    setSavedNotice(false);
  }, [selectedEmp?.id]);

  const num = (v: string) => Math.max(0, Number(v) || 0);

  const draft = {
    basicSalary: num(basicSalary),
    hra: num(hra),
    da: num(da),
    otherAllowances: num(otherAllowances),
    pfDeduction: num(pfDeduction),
    taxDeduction: num(taxDeduction),
    otherDeductions: num(otherDeductions),
  };

  const totalAllowances = calculateAllowances(draft);
  const grossSalary = calculateGrossSalary(draft);
  const totalDeductions = calculateDeductions(draft);
  const netSalary = calculateNetSalary(draft);

  const handleAutoPreset = () => {
    const std = computeStandardComponents(draft.basicSalary);
    setHra(String(std.hra));
    setDa(String(std.da));
    setOtherAllowances(String(std.otherAllowances));
    setPfDeduction(String(std.pfDeduction));
    setTaxDeduction(String(std.taxDeduction));
    setOtherDeductions(String(std.otherDeductions));
  };

  const handleSaveToEmployee = () => {
    if (!selectedEmp) return;
    onUpdateEmployeeSalary({
      ...selectedEmp,
      ...draft,
    });
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1E1B4B]">Calculate Salary</h1>
          <p className="text-sm text-slate-500 mt-1">
            Module 2 · Interactive gross &amp; net salary calculator with itemized allowances and deductions
          </p>
        </div>
        {selectedEmp && (
          <button
            type="button"
            onClick={() => onOpenPaySlip({ ...selectedEmp, ...draft })}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#6C63FF] to-[#574CE8] px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:from-[#5D54F5] hover:to-[#4B40DB] transition-all whitespace-nowrap shrink-0"
          >
            <ReceiptIndianRupee className="w-4 h-4" />
            Preview Pay Slip
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 rounded-2xl bg-white border border-[#E4E3FA] p-6 space-y-5 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="flex-1 min-w-[220px]">
              <label htmlFor="calc-emp-select" className="block text-xs font-semibold text-[#1E1B4B] mb-1.5">
                Select Employee
              </label>
              <select
                id="calc-emp-select"
                value={selectedEmp?.id || ''}
                onChange={(e) => setSelectedId(e.target.value)}
                className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3.5 py-2.5 text-sm font-medium text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.id} - {emp.name} ({emp.department})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleAutoPreset}
              className="mt-5 inline-flex items-center gap-1.5 rounded-xl border border-[#DDDDFB] bg-[#F4F3FF] px-3.5 py-2.5 text-xs font-semibold text-[#4F46E5] hover:bg-[#EAE8FF] transition-colors whitespace-nowrap shrink-0"
            >
              <Calculator className="w-3.5 h-3.5" />
              Auto-Fill Percentages
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="calc-basic" className="block text-xs font-semibold text-slate-700 mb-1">
                Basic Salary (₹)
              </label>
              <input
                id="calc-basic"
                type="number"
                min={0}
                value={basicSalary}
                onChange={(e) => setBasicSalary(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-hra" className="block text-xs font-semibold text-slate-700 mb-1">
                HRA Allowance (₹)
              </label>
              <input
                id="calc-hra"
                type="number"
                min={0}
                value={hra}
                onChange={(e) => setHra(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-da" className="block text-xs font-semibold text-slate-700 mb-1">
                DA Allowance (₹)
              </label>
              <input
                id="calc-da"
                type="number"
                min={0}
                value={da}
                onChange={(e) => setDa(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-other-all" className="block text-xs font-semibold text-slate-700 mb-1">
                Special / Other Allowances (₹)
              </label>
              <input
                id="calc-other-all"
                type="number"
                min={0}
                value={otherAllowances}
                onChange={(e) => setOtherAllowances(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-pf" className="block text-xs font-semibold text-slate-700 mb-1">
                PF Deduction (₹)
              </label>
              <input
                id="calc-pf"
                type="number"
                min={0}
                value={pfDeduction}
                onChange={(e) => setPfDeduction(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-tax" className="block text-xs font-semibold text-slate-700 mb-1">
                Income Tax / TDS (₹)
              </label>
              <input
                id="calc-tax"
                type="number"
                min={0}
                value={taxDeduction}
                onChange={(e) => setTaxDeduction(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="calc-other-ded" className="block text-xs font-semibold text-slate-700 mb-1">
                Professional Tax / Other (₹)
              </label>
              <input
                id="calc-other-ded"
                type="number"
                min={0}
                value={otherDeductions}
                onChange={(e) => setOtherDeductions(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-3 flex items-center justify-between gap-3 border-t border-slate-100">
            {savedNotice ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                <CheckCircle2 className="w-4 h-4" />
                Saved salary changes to {selectedEmp?.name}
              </span>
            ) : (
              <span className="text-xs text-slate-500">
                Adjust any field to see real-time salary calculation
              </span>
            )}
            <button
              type="button"
              onClick={handleSaveToEmployee}
              disabled={!selectedEmp}
              className="inline-flex items-center gap-2 rounded-xl bg-[#1E1B4B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#312E81] transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              Save to Employee
            </button>
          </div>
        </div>

        {/* Live Calculation Summary Card */}
        <motion.div
          key={`${grossSalary}-${netSalary}`}
          initial={{ opacity: 0.85, scale: 0.99 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
          className="lg:col-span-5 rounded-2xl bg-white border border-[#E4E3FA] p-6 space-y-5 shadow-xs"
        >
          <h2 className="text-base font-bold text-[#1E1B4B]">Live Salary Summary</h2>

          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-600">Basic Salary</span>
              <span className="font-mono tabular-nums font-medium text-[#1E1B4B]">
                {formatINR(draft.basicSalary)}
              </span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-600">Total Allowances</span>
              <span className="font-mono tabular-nums font-medium text-emerald-700">
                +{formatINR(totalAllowances)}
              </span>
            </div>
            <div className="flex items-center justify-between py-2 border-t border-slate-100 font-semibold">
              <span className="text-[#1E1B4B]">Gross Salary</span>
              <span className="font-mono tabular-nums text-[#1E1B4B]">
                {formatINR(grossSalary)}
              </span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-600">Total Deductions</span>
              <span className="font-mono tabular-nums font-medium text-rose-600">
                -{formatINR(totalDeductions)}
              </span>
            </div>
          </div>

          <div className="rounded-2xl bg-gradient-to-br from-[#EFEFFF] to-[#E2E0FF] border border-[#D4D2FA] p-5 text-center space-y-1">
            <p className="text-xs font-semibold text-[#4F46E5]">Net Take-Home Salary</p>
            <p className="text-3xl font-bold font-mono tabular-nums text-[#1E1B4B]">
              {formatINR(netSalary)}
            </p>
            <p className="text-xs text-slate-600 pt-1">
              Gross ({formatINR(grossSalary)}) − Deductions ({formatINR(totalDeductions)})
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
