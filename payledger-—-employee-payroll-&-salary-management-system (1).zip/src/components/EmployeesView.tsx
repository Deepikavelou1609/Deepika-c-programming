import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  Plus,
  Eye,
  Pencil,
  Trash2,
  CheckCircle2,
  Clock,
  Users,
} from 'lucide-react';
import { DEPARTMENTS, Employee } from '../types/payroll';
import {
  calculateAllowances,
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  formatINR,
} from '../utils/payrollCalc';

interface EmployeesViewProps {
  employees: Employee[];
  onAddEmployee: () => void;
  onEditEmployee: (employee: Employee) => void;
  onDeleteEmployee: (employee: Employee) => void;
  onOpenPaySlip: (employee: Employee) => void;
}

export const EmployeesView: React.FC<EmployeesViewProps> = ({
  employees,
  onAddEmployee,
  onEditEmployee,
  onDeleteEmployee,
  onOpenPaySlip,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Pending'>('All');

  const filteredEmployees = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return employees.filter((emp) => {
      const matchesQuery =
        !q ||
        emp.id.toLowerCase().includes(q) ||
        emp.name.toLowerCase().includes(q) ||
        emp.department.toLowerCase().includes(q) ||
        emp.designation.toLowerCase().includes(q);
      const matchesDept = selectedDept === 'All' || emp.department === selectedDept;
      const matchesStatus = statusFilter === 'All' || emp.paymentStatus === statusFilter;
      return matchesQuery && matchesDept && matchesStatus;
    });
  }, [employees, searchQuery, selectedDept, statusFilter]);

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedDept('All');
    setStatusFilter('All');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1E1B4B]">View Employees</h1>
          <p className="text-sm text-slate-500 mt-1">
            Module 1 · Search, view, edit, and manage employee salary records
          </p>
        </div>
        <motion.button
          whileHover={{ y: -1 }}
          whileTap={{ scale: 0.98 }}
          type="button"
          onClick={onAddEmployee}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-indigo-500/20 hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Employee
        </motion.button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="rounded-2xl bg-white border border-[#E2E0FA] p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#7C78B8] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ID, name, department, or role..."
            aria-label="Search employees"
            className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] pl-10 pr-3 py-2 text-sm text-[#1E1B4B] placeholder:text-slate-400 focus:border-[#635BFF] focus:bg-white focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            aria-label="Filter by department"
            className="rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-sm text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
          >
            <option value="All">All Departments</option>
            {DEPARTMENTS.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-1 p-1 bg-[#F2F1FF] rounded-xl border border-[#E4E3FA]">
            {(['All', 'Paid', 'Pending'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === status
                    ? 'bg-white text-[#4F46E5] shadow-xs'
                    : 'text-slate-600 hover:text-[#1E1B4B]'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Employee Records Table */}
      <div className="rounded-2xl bg-white border border-[#E2E0FA] overflow-hidden shadow-xs">
        {filteredEmployees.length === 0 ? (
          <div className="p-12 text-center">
            <Users className="w-10 h-10 text-indigo-200 mx-auto mb-3" />
            <h2 className="text-base font-semibold text-[#1E1B4B]">
              {employees.length === 0 ? 'No employee records yet' : 'No matching employees found'}
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
              {employees.length === 0
                ? 'Create your first employee record to begin calculating gross and net salaries.'
                : 'Try adjusting your search query, department filter, or payment status.'}
            </p>
            <div className="mt-5">
              {employees.length === 0 ? (
                <button
                  type="button"
                  onClick={onAddEmployee}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#5B52E5] px-4 py-2 text-sm font-medium text-white hover:bg-[#4F46E5]"
                >
                  <Plus className="w-4 h-4" />
                  Add First Employee
                </button>
              ) : (
                <button
                  type="button"
                  onClick={clearFilters}
                  className="rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-4 py-2 text-sm font-medium text-[#1E1B4B] hover:bg-[#ECEBFF]"
                >
                  Reset Filters
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#ECEBFF] border-b border-[#DFDDFA] text-xs font-semibold text-[#1E1B4B]">
                  <th className="py-3 px-5">ID</th>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4 text-right">Basic</th>
                  <th className="py-3 px-4 text-right">Allowances</th>
                  <th className="py-3 px-4 text-right">Gross</th>
                  <th className="py-3 px-4 text-right">Deductions</th>
                  <th className="py-3 px-4 text-right">Net Pay</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-5 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F0EFFE] text-sm">
                {filteredEmployees.map((emp) => {
                  const allowances = calculateAllowances(emp);
                  const gross = calculateGrossSalary(emp);
                  const deductions = calculateDeductions(emp);
                  const net = calculateNetSalary(emp);

                  return (
                    <tr key={emp.id} className="hover:bg-[#FAF9FF] transition-colors">
                      <td className="py-3 px-5 font-mono tabular-nums text-xs font-medium text-[#312E81]">
                        {emp.id}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-semibold text-[#1E1B4B]">{emp.name}</p>
                        <p className="text-xs text-slate-500">{emp.designation}</p>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{emp.department}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                        {formatINR(emp.basicSalary)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                        {formatINR(allowances)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                        {formatINR(gross)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-rose-600">
                        -{formatINR(deductions)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-[#1E1B4B]">
                        {formatINR(net)}
                      </td>
                      <td className="py-3 px-4">
                        {emp.paymentStatus === 'Paid' ? (
                          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Paid
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700">
                            <Clock className="w-3.5 h-3.5" />
                            Pending
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-5">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onOpenPaySlip(emp)}
                            className="inline-flex items-center gap-1 rounded-lg bg-[#E6EEFF] border border-[#CFE0FF] px-2.5 py-1 text-xs font-medium text-[#2E5AAC] hover:bg-[#D6E4FF] transition-colors whitespace-nowrap shrink-0"
                          >
                            <Eye className="w-3 h-3" />
                            View
                          </button>
                          <button
                            type="button"
                            onClick={() => onEditEmployee(emp)}
                            className="inline-flex items-center gap-1 rounded-lg bg-[#EFEAFE] border border-[#DDD4FC] px-2.5 py-1 text-xs font-medium text-[#5B45B8] hover:bg-[#E4DCFD] transition-colors whitespace-nowrap shrink-0"
                          >
                            <Pencil className="w-3 h-3" />
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteEmployee(emp)}
                            className="inline-flex items-center gap-1 rounded-lg bg-[#FDE8EA] border border-[#F9CFD4] px-2.5 py-1 text-xs font-medium text-[#B83242] hover:bg-[#FAD6DA] transition-colors whitespace-nowrap shrink-0"
                          >
                            <Trash2 className="w-3 h-3" />
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
