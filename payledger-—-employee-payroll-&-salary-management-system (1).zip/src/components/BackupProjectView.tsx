import React, { useRef, useState } from 'react';
import {
  Download,
  Upload,
  RotateCcw,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Employee } from '../types/payroll';

interface BackupProjectViewProps {
  employees: Employee[];
  onExportJSON: () => void;
  onExportCSV: () => void;
  onRestoreJSON: (imported: Employee[]) => void;
  onResetSampleData: () => void;
}

export const BackupProjectView: React.FC<BackupProjectViewProps> = ({
  employees,
  onExportJSON,
  onExportCSV,
  onRestoreJSON,
  onResetSampleData,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(
    null
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const list = Array.isArray(parsed) ? parsed : parsed?.employees;
        if (!Array.isArray(list) || list.length === 0) {
          setFeedback({
            type: 'error',
            message: 'Invalid backup file. Expected an employees array.',
          });
          return;
        }
        const valid = list.every(
          (item) =>
            typeof item.id === 'string' &&
            typeof item.name === 'string' &&
            typeof item.basicSalary === 'number'
        );
        if (!valid) {
          setFeedback({
            type: 'error',
            message: 'Backup file schema mismatch. Please select a valid JSON backup.',
          });
          return;
        }
        onRestoreJSON(list);
        setFeedback({
          type: 'success',
          message: `Restored ${list.length} employee records from "${file.name}".`,
        });
      } catch {
        setFeedback({
          type: 'error',
          message: 'Could not parse JSON file. Ensure the file is valid JSON.',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#1E1B4B]">
          Settings, Backup &amp; Capstone Overview
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Permanent JSON backup/recovery, CSV export, login details, and project architecture
        </p>
      </div>

      {feedback && (
        <div
          className={`rounded-xl border px-4 py-3 text-sm flex items-center gap-2.5 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-white border border-[#E2E0FA] p-6 space-y-4 shadow-xs">
          <div>
            <h2 className="text-base font-bold text-[#1E1B4B]">Backup &amp; Export Records</h2>
            <p className="text-sm text-slate-500 mt-1">
              Download structured employee records (<span className="font-mono">{employees.length}</span>{' '}
              stored) for archival or spreadsheet reporting.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={onExportJSON}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-4 py-2 text-sm font-semibold text-white hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
            >
              <Download className="w-4 h-4" />
              Backup JSON
            </button>
            <button
              type="button"
              onClick={onExportCSV}
              className="inline-flex items-center gap-2 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-4 py-2 text-sm font-semibold text-[#1E1B4B] hover:bg-[#ECEBFF] transition-colors whitespace-nowrap shrink-0"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#5B52E5]" />
              Export Payroll CSV
            </button>
          </div>
        </div>

        <div className="rounded-2xl bg-white border border-[#E2E0FA] p-6 space-y-4 shadow-xs">
          <div>
            <h2 className="text-base font-bold text-[#1E1B4B]">Restore or Reset Storage</h2>
            <p className="text-sm text-slate-500 mt-1">
              Import a saved JSON backup file or restore the default student capstone dataset.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-4 py-2 text-sm font-semibold text-[#1E1B4B] hover:bg-[#ECEBFF] transition-colors whitespace-nowrap shrink-0"
            >
              <Upload className="w-4 h-4 text-[#5B52E5]" />
              Restore from JSON
            </button>
            <button
              type="button"
              onClick={() => {
                onResetSampleData();
                setFeedback({
                  type: 'success',
                  message: 'Restored default 5-employee sample dataset.',
                });
              }}
              className="inline-flex items-center gap-2 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-4 py-2 text-sm font-semibold text-[#1E1B4B] hover:bg-[#ECEBFF] transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-4 h-4 text-[#5B52E5]" />
              Reset Sample Data
            </button>
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-[#E2E0FA] p-6 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-[#F0EFFE]">
          <div>
            <h2 className="text-base font-bold text-[#1E1B4B]">
              Employee Payroll &amp; Salary Management System — Capstone Architecture
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Presented by Deepika V (1965260075) · Laksheka S A (192513030)
            </p>
          </div>
          <span className="text-xs font-mono text-[#5B52E5]">
            Demo Login: admin / admin123
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div className="space-y-2">
            <h3 className="font-semibold text-[#1E1B4B]">
              01. Employee Record Entry &amp; Storage (Module 1)
            </h3>
            <p className="text-slate-600 leading-relaxed">
              Upgrades manual registers and C <span className="font-mono">fwrite()</span> file
              handling into a graphical web interface with persistent browser storage and JSON
              backup/restore. Supports Add, View, Update, Delete, and Search by ID.
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold text-[#1E1B4B]">
              02. Salary Calculation &amp; Pay Slip Generation (Module 2)
            </h3>
            <p className="text-slate-600 leading-relaxed">
              Automates Gross Salary (<span className="font-mono">Basic + Allowances</span>) and Net
              Salary (<span className="font-mono">Gross − Deductions</span>), generating organized
              monthly payroll reports, interactive salary calculation, and printable pay slips.
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-[#F0EFFE]">
          <p className="text-xs font-semibold text-[#1E1B4B] mb-2">
            Stored Record Preview (<span className="font-mono">struct Employee</span> JSON)
          </p>
          <pre className="rounded-xl bg-[#1E1B4B] text-indigo-100 p-4 text-xs font-mono overflow-x-auto leading-relaxed">
{JSON.stringify(employees[0] || {}, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
};
