import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  Eye,
  Pencil,
  Trash2,
  Users,
  Calendar,
  Calculator,
  BarChart3,
  IndianRupee,
  Wallet,
  CheckCircle2,
} from 'lucide-react';
import { Employee, NavSection } from '../types/payroll';
import {
  calculateAllowances,
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  formatINR,
} from '../utils/payrollCalc';

interface DashboardViewProps {
  employees: Employee[];
  username: string;
  selectedMonthShortLabel: string;
  onNavigate: (section: NavSection) => void;
  onEditEmployee: (employee: Employee) => void;
  onDeleteEmployee: (employee: Employee) => void;
  onOpenPaySlip: (employee: Employee) => void;
  onQuickUpdateSalary: (id: string, basic: number, allowances: number, deductions: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  employees,
  username,
  selectedMonthShortLabel,
  onNavigate,
  onEditEmployee,
  onDeleteEmployee,
  onOpenPaySlip,
  onQuickUpdateSalary,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [calcEmpId, setCalcEmpId] = useState<string>(employees[0]?.id || '');
  const [calcBasic, setCalcBasic] = useState<string>('25000');
  const [calcAllowances, setCalcAllowances] = useState<string>('5000');
  const [calcDeductions, setCalcDeductions] = useState<string>('2000');
  const [calculatedResult, setCalculatedResult] = useState<{
    gross: number;
    net: number;
  } | null>(null);
  const [appliedSaved, setAppliedSaved] = useState(false);

  const selectedCalcEmp = useMemo(
    () => employees.find((e) => e.id === calcEmpId) || employees[0] || null,
    [employees, calcEmpId]
  );

  useEffect(() => {
    if (!selectedCalcEmp) return;
    const allow = calculateAllowances(selectedCalcEmp);
    const ded = calculateDeductions(selectedCalcEmp);
    setCalcEmpId(selectedCalcEmp.id);
    setCalcBasic(String(selectedCalcEmp.basicSalary));
    setCalcAllowances(String(allow));
    setCalcDeductions(String(ded));
    setCalculatedResult({
      gross: selectedCalcEmp.basicSalary + allow,
      net: Math.max(0, selectedCalcEmp.basicSalary + allow - ded),
    });
    setAppliedSaved(false);
  }, [selectedCalcEmp?.id]);

  const filteredEmployees = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return employees;
    return employees.filter(
      (emp) =>
        emp.id.toLowerCase().includes(q) ||
        emp.name.toLowerCase().includes(q) ||
        emp.department.toLowerCase().includes(q)
    );
  }, [employees, searchQuery]);

  const totalBasic = employees.reduce((sum, e) => sum + e.basicSalary, 0);
  const totalAllowances = employees.reduce((sum, e) => sum + calculateAllowances(e), 0);
  const totalGross = employees.reduce((sum, e) => sum + calculateGrossSalary(e), 0);
  const totalDeductions = employees.reduce((sum, e) => sum + calculateDeductions(e), 0);
  const totalNet = employees.reduce((sum, e) => sum + calculateNetSalary(e), 0);

  const handleCalculateClick = (e: React.FormEvent) => {
    e.preventDefault();
    const b = Math.max(0, Number(calcBasic) || 0);
    const a = Math.max(0, Number(calcAllowances) || 0);
    const d = Math.max(0, Number(calcDeductions) || 0);
    const gross = b + a;
    const net = Math.max(0, gross - d);
    setCalculatedResult({ gross, net });

    if (selectedCalcEmp) {
      onQuickUpdateSalary(selectedCalcEmp.id, b, a, d);
      setAppliedSaved(true);
      window.setTimeout(() => setAppliedSaved(false), 2200);
    }
  };

  const liveGross =
    calculatedResult?.gross ??
    (Math.max(0, Number(calcBasic) || 0) + Math.max(0, Number(calcAllowances) || 0));
  const liveNet =
    calculatedResult?.net ??
    Math.max(0, liveGross - Math.max(0, Number(calcDeductions) || 0));

  return (
    <div className="space-y-5">
      {/* Welcome Banner matching pastel mockup */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="rounded-2xl bg-gradient-to-r from-[#E6E5FF] via-[#DFDEFF] to-[#D4D2FF] border border-[#D3D1FA] px-6 py-5 flex items-center justify-between gap-6 overflow-hidden"
      >
        <div>
          <h1 className="text-2xl sm:text-[26px] font-bold tracking-tight text-[#1E1B4B]">
            Welcome, {username}!
          </h1>
          <p className="text-sm text-[#433F75] mt-1">
            Manage your employees and handle payroll with ease.
          </p>
        </div>

        {/* Crisp Calendar + Clock SVG */}
        <div className="hidden sm:block shrink-0" aria-hidden="true">
          <svg viewBox="0 0 130 90" className="w-28 h-20">
            <rect x="22" y="14" width="68" height="58" rx="10" fill="#F8F8FF" stroke="#6D67E4" strokeWidth="2.5" />
            <path d="M22 30h68" stroke="#6D67E4" strokeWidth="2.5" />
            <rect x="38" y="8" width="5" height="12" rx="2.5" fill="#6D67E4" />
            <rect x="68" y="8" width="5" height="12" rx="2.5" fill="#6D67E4" />
            <rect x="32" y="38" width="10" height="8" rx="2" fill="#C7C5FB" />
            <rect x="47" y="38" width="10" height="8" rx="2" fill="#C7C5FB" />
            <rect x="62" y="38" width="10" height="8" rx="2" fill="#C7C5FB" />
            <rect x="32" y="51" width="10" height="8" rx="2" fill="#C7C5FB" />
            <rect x="47" y="51" width="10" height="8" rx="2" fill="#C7C5FB" />
            <circle cx="94" cy="60" r="20" fill="#FFFFFF" stroke="#312E81" strokeWidth="2.5" />
            <path d="M94 50v10l7 4" stroke="#312E81" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          </svg>
        </div>
      </motion.div>

      {/* 4 Pastel KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, delay: 0.04 }}
          whileHover={{ y: -2 }}
          className="rounded-2xl bg-[#ECEBFF] border border-[#DCDAFA] p-4 flex items-center gap-4 shadow-xs"
        >
          <div className="w-12 h-12 rounded-xl bg-[#D8D6FD] flex items-center justify-center shrink-0">
            <Users className="w-6 h-6 text-[#5B52E5]" />
          </div>
          <div>
            <p className="text-2xl font-bold font-mono tabular-nums text-[#1E1B4B]">
              {employees.length}
            </p>
            <p className="text-xs font-medium text-[#433F75]">Total Employees</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, delay: 0.08 }}
          whileHover={{ y: -2 }}
          className="rounded-2xl bg-[#E3F5EA] border border-[#CBEAD7] p-4 flex items-center gap-4 shadow-xs"
        >
          <div className="w-12 h-12 rounded-xl bg-[#C6ECD4] flex items-center justify-center shrink-0">
            <Wallet className="w-6 h-6 text-[#2E8555]" />
          </div>
          <div>
            <p className="text-2xl font-bold font-mono tabular-nums text-[#1E1B4B]">
              {formatINR(totalGross)}
            </p>
            <p className="text-xs font-medium text-[#2A5E42]">Total Gross Salary</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, delay: 0.12 }}
          whileHover={{ y: -2 }}
          className="rounded-2xl bg-[#FDECE4] border border-[#F7D7C8] p-4 flex items-center gap-4 shadow-xs"
        >
          <div className="w-12 h-12 rounded-full bg-[#DF5B44] flex items-center justify-center shrink-0 shadow-xs">
            <IndianRupee className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-2xl font-bold font-mono tabular-nums text-[#1E1B4B]">
              {formatINR(totalNet)}
            </p>
            <p className="text-xs font-medium text-[#7A3B2E]">Total Net Salary</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, delay: 0.16 }}
          whileHover={{ y: -2 }}
          className="rounded-2xl bg-[#ECEAFF] border border-[#DCD8FA] p-4 flex items-center gap-4 shadow-xs"
        >
          <div className="w-12 h-12 rounded-xl bg-[#D9D5FC] flex items-center justify-center shrink-0">
            <Calendar className="w-6 h-6 text-[#6457E8]" />
          </div>
          <div>
            <p className="text-2xl font-bold text-[#1E1B4B] whitespace-nowrap">
              {selectedMonthShortLabel}
            </p>
            <p className="text-xs font-medium text-[#433F75]">Last Payroll</p>
          </div>
        </motion.div>
      </div>

      {/* Middle 2-Column Layout: Employee Records + Salary Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: Employee Records Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.18 }}
          className="lg:col-span-8 rounded-2xl bg-white border border-[#E2E0FA] p-5 flex flex-col justify-between shadow-xs"
        >
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2.5">
                <Users className="w-5 h-5 text-[#5B52E5]" />
                <h2 className="text-base font-bold text-[#1E1B4B]">Employee Records</h2>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-[#7C78B8] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by Employee ID..."
                  aria-label="Search by Employee ID"
                  className="w-full rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] pl-9 pr-3 py-1.5 text-xs text-[#1E1B4B] placeholder:text-slate-400 focus:border-[#635BFF] focus:bg-white focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div className="overflow-x-auto rounded-xl border border-[#E6E5FA]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#ECEBFF] text-xs font-semibold text-[#1E1B4B]">
                    <th className="py-2.5 px-3.5">ID</th>
                    <th className="py-2.5 px-3.5">Name</th>
                    <th className="py-2.5 px-3.5">Department</th>
                    <th className="py-2.5 px-3.5 text-right">Basic Salary</th>
                    <th className="py-2.5 px-3.5 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F0EFFE] text-sm">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-sm text-slate-500">
                        No employees matched "{searchQuery}".
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.slice(0, 6).map((emp) => (
                      <tr key={emp.id} className="hover:bg-[#FAF9FF] transition-colors">
                        <td className="py-2.5 px-3.5 font-mono tabular-nums text-xs font-medium text-[#312E81]">
                          {emp.id}
                        </td>
                        <td className="py-2.5 px-3.5 font-medium text-[#1E1B4B] whitespace-nowrap">
                          {emp.name}
                        </td>
                        <td className="py-2.5 px-3.5 text-slate-700 whitespace-nowrap">
                          {emp.department}
                        </td>
                        <td className="py-2.5 px-3.5 text-right font-mono tabular-nums font-medium text-[#1E1B4B]">
                          {formatINR(emp.basicSalary)}
                        </td>
                        <td className="py-2.5 px-3.5">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenPaySlip(emp)}
                              className="inline-flex items-center gap-1 rounded-lg bg-[#E6EEFF] border border-[#CFE0FF] px-2.5 py-1 text-xs font-medium text-[#2E5AAC] hover:bg-[#D6E4FF] transition-colors whitespace-nowrap shrink-0"
                            >
                              <Eye className="w-3 h-3" />
                              View
                            </button>
                            <button
                              type="button"
                              onClick={() => onEditEmployee(emp)}
                              className="inline-flex items-center gap-1 rounded-lg bg-[#EFEAFE] border border-[#DDD4FC] px-2.5 py-1 text-xs font-medium text-[#5B45B8] hover:bg-[#E4DCFD] transition-colors whitespace-nowrap shrink-0"
                            >
                              <Pencil className="w-3 h-3" />
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteEmployee(emp)}
                              className="inline-flex items-center gap-1 rounded-lg bg-[#FDE8EA] border border-[#F9CFD4] px-2.5 py-1 text-xs font-medium text-[#B83242] hover:bg-[#FAD6DA] transition-colors whitespace-nowrap shrink-0"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {employees.length > 6 && (
            <div className="mt-3 text-right">
              <button
                type="button"
                onClick={() => onNavigate('employees')}
                className="text-xs font-semibold text-[#5B52E5] hover:underline"
              >
                View all {employees.length} employees →
              </button>
            </div>
          )}
        </motion.div>

        {/* Right: Salary Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.22 }}
          className="lg:col-span-4 rounded-2xl bg-white border border-[#E2E0FA] p-5 flex flex-col justify-between shadow-xs"
        >
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-[#F0EFFE]">
              <div className="p-1.5 rounded-lg bg-[#ECEBFF] text-[#5B52E5]">
                <BarChart3 className="w-4 h-4" />
              </div>
              <h2 className="text-base font-bold text-[#1E1B4B]">Salary Summary</h2>
            </div>

            <div className="space-y-2.5 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Total Basic Salary</span>
                <span className="font-mono tabular-nums font-semibold text-[#1E1B4B]">
                  {formatINR(totalBasic)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Total Allowances</span>
                <span className="font-mono tabular-nums font-semibold text-[#1E1B4B]">
                  {formatINR(totalAllowances)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Total Deductions</span>
                <span className="font-mono tabular-nums font-semibold text-rose-600">
                  {formatINR(totalDeductions)}
                </span>
              </div>
            </div>

            <div className="rounded-xl bg-[#ECEBFF] border border-[#D8D6FA] p-4 text-center space-y-1">
              <p className="text-xs font-semibold text-[#433F75]">Net Salary This Month</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#312E81]">
                {formatINR(totalNet)}
              </p>
            </div>
          </div>

          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.985 }}
            type="button"
            onClick={() => onNavigate('payroll')}
            className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-indigo-500/20 hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all"
          >
            <BarChart3 className="w-4 h-4" />
            View Report
          </motion.button>
        </motion.div>
      </div>

      {/* Bottom Interactive Calculate Salary Widget */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
        className="rounded-2xl bg-white border border-[#E2E0FA] p-5 shadow-xs"
      >
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-[#ECEBFF] text-[#5B52E5]">
              <Calculator className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-[#1E1B4B]">Calculate Salary</h2>
          </div>
          {appliedSaved && (
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Calculated &amp; updated {selectedCalcEmp?.name}
            </span>
          )}
        </div>

        <form
          onSubmit={handleCalculateClick}
          className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center"
        >
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 flex items-center gap-3">
              <label
                htmlFor="dash-calc-emp"
                className="w-28 text-xs font-semibold text-[#1E1B4B] shrink-0"
              >
                Employee ID:
              </label>
              <select
                id="dash-calc-emp"
                value={selectedCalcEmp?.id || ''}
                onChange={(e) => setCalcEmpId(e.target.value)}
                className="flex-1 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-2 text-xs font-medium text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.id} - {emp.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2 flex items-center gap-3">
              <label
                htmlFor="dash-calc-basic"
                className="w-28 text-xs font-semibold text-[#1E1B4B] shrink-0"
              >
                Basic Salary (₹):
              </label>
              <input
                id="dash-calc-basic"
                type="number"
                min={0}
                value={calcBasic}
                onChange={(e) => setCalcBasic(e.target.value)}
                className="flex-1 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-1.5 text-xs font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2 flex items-center gap-3">
              <label
                htmlFor="dash-calc-allow"
                className="w-28 text-xs font-semibold text-[#1E1B4B] shrink-0"
              >
                Allowances (₹):
              </label>
              <input
                id="dash-calc-allow"
                type="number"
                min={0}
                value={calcAllowances}
                onChange={(e) => setCalcAllowances(e.target.value)}
                className="flex-1 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-1.5 text-xs font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2 flex items-center gap-3">
              <label
                htmlFor="dash-calc-ded"
                className="w-28 text-xs font-semibold text-[#1E1B4B] shrink-0"
              >
                Deductions (₹):
              </label>
              <input
                id="dash-calc-ded"
                type="number"
                min={0}
                value={calcDeductions}
                onChange={(e) => setCalcDeductions(e.target.value)}
                className="flex-1 rounded-xl border border-[#DDDDFB] bg-[#FAF9FF] px-3 py-1.5 text-xs font-mono tabular-nums text-[#1E1B4B] focus:border-[#635BFF] focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          <div className="lg:col-span-3 flex justify-center">
            <motion.button
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.97 }}
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-6 py-3 text-sm font-semibold text-white shadow-sm shadow-indigo-500/20 hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
            >
              <Calculator className="w-4 h-4" />
              Calculate
            </motion.button>
          </div>

          <motion.div
            key={`${liveGross}-${liveNet}`}
            initial={{ opacity: 0.85, scale: 0.99 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.2 }}
            className="lg:col-span-4 rounded-xl bg-[#ECEBFF] border border-[#D8D6FA] p-4 text-center space-y-2.5"
          >
            <div>
              <p className="text-xs font-medium text-[#433F75]">Gross Salary</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#1E1B4B]">
                {formatINR(liveGross)}
              </p>
            </div>
            <div className="border-t border-[#D3D0F5] pt-2">
              <p className="text-xs font-medium text-[#433F75]">Net Salary</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#312E81]">
                {formatINR(liveNet)}
              </p>
            </div>
          </motion.div>
        </form>
      </motion.div>
    </div>
  );
};
