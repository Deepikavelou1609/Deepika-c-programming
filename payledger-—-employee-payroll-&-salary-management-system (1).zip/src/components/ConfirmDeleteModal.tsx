import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle } from 'lucide-react';
import { Employee } from '../types/payroll';

interface ConfirmDeleteModalProps {
  employee: Employee | null;
  onCancel: () => void;
  onConfirm: (id: string) => void;
}

export const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  employee,
  onCancel,
  onConfirm,
}) => {
  if (!employee) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1E1B4B]/40 backdrop-blur-xs p-4 no-print"
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md rounded-2xl bg-white border border-[#DDDDFB] shadow-2xl p-6 space-y-4"
      >
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-rose-50 text-rose-600 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h2 id="delete-modal-title" className="text-base font-bold text-[#1E1B4B]">
              Delete Employee Record
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Are you sure you want to remove{' '}
              <span className="font-semibold text-[#1E1B4B]">{employee.name}</span> (
              <span className="font-mono">{employee.id}</span>)? This action cannot be undone.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-xl border border-[#DDDDFB] bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onConfirm(employee.id)}
            className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700 transition-colors whitespace-nowrap shrink-0"
          >
            Delete Record
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};
