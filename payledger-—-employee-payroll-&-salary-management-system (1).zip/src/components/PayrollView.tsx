import React from 'react';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  Clock,
  FileSpreadsheet,
  ReceiptIndianRupee,
  Send,
} from 'lucide-react';
import { Employee, PAYROLL_MONTHS } from '../types/payroll';
import {
  calculateAllowances,
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  formatINR,
} from '../utils/payrollCalc';

interface PayrollViewProps {
  employees: Employee[];
  selectedMonth: string;
  onChangeMonth: (month: string) => void;
  onProcessAllPending: () => void;
  onTogglePaymentStatus: (id: string) => void;
  onOpenPaySlip: (employee: Employee) => void;
  onExportCSV: () => void;
}

export const PayrollView: React.FC<PayrollViewProps> = ({
  employees,
  selectedMonth,
  onChangeMonth,
  onProcessAllPending,
  onTogglePaymentStatus,
  onOpenPaySlip,
  onExportCSV,
}) => {
  const pendingCount = employees.filter((e) => e.paymentStatus === 'Pending').length;

  const totals = employees.reduce(
    (acc, emp) => {
      acc.basic += emp.basicSalary;
      acc.allowances += calculateAllowances(emp);
      acc.gross += calculateGrossSalary(emp);
      acc.deductions += calculateDeductions(emp);
      acc.net += calculateNetSalary(emp);
      return acc;
    },
    { basic: 0, allowances: 0, gross: 0, deductions: 0, net: 0 }
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1E1B4B]">Payroll Report</h1>
          <p className="text-sm text-slate-500 mt-1">
            Module 2 · Monthly gross salary, deductions, net payout report &amp; pay slips
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedMonth}
            onChange={(e) => onChangeMonth(e.target.value)}
            aria-label="Select payroll month"
            className="rounded-xl border border-[#DDDDFB] bg-white px-3 py-2 text-sm font-medium text-[#1E1B4B] focus:border-[#635BFF] focus:outline-none"
          >
            {PAYROLL_MONTHS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.fullLabel}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={onExportCSV}
            className="inline-flex items-center gap-2 rounded-xl border border-[#DDDDFB] bg-white px-4 py-2 text-sm font-semibold text-[#1E1B4B] hover:bg-[#FAF9FF] transition-colors whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#5B52E5]" />
            Export CSV
          </button>

          {pendingCount > 0 && (
            <motion.button
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={onProcessAllPending}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-indigo-500/20 hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
            >
              <Send className="w-4 h-4" />
              Process Pending ({pendingCount})
            </motion.button>
          )}
        </div>
      </div>

      {/* Formula Bar */}
      <div className="rounded-2xl bg-white border border-[#E2E0FA] px-5 py-3.5 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-600 shadow-xs">
        <div>
          <span className="font-semibold text-[#1E1B4B]">Salary Formula:</span>{' '}
          <span className="font-mono">Gross = Basic + Allowances</span>
          <span className="mx-2 text-slate-300">|</span>
          <span className="font-mono">Net = Gross − Deductions</span>
        </div>
        <div className="font-mono tabular-nums font-bold text-[#4F46E5]">
          Net Payroll Total: {formatINR(totals.net)}
        </div>
      </div>

      {/* Complete Payroll Report Table */}
      <div className="rounded-2xl bg-white border border-[#E2E0FA] overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#ECEBFF] border-b border-[#DFDDFA] text-xs font-semibold text-[#1E1B4B]">
                <th className="py-3 px-5">ID</th>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4 text-right">Basic</th>
                <th className="py-3 px-4 text-right">Allowances</th>
                <th className="py-3 px-4 text-right">Gross Salary</th>
                <th className="py-3 px-4 text-right">Deductions</th>
                <th className="py-3 px-4 text-right">Net Salary</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-5 text-right">Pay Slip</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0EFFE] text-sm">
              {employees.map((emp) => {
                const allowances = calculateAllowances(emp);
                const gross = calculateGrossSalary(emp);
                const deductions = calculateDeductions(emp);
                const net = calculateNetSalary(emp);

                return (
                  <tr key={emp.id} className="hover:bg-[#FAF9FF] transition-colors">
                    <td className="py-3 px-5 font-mono tabular-nums text-xs font-medium text-[#312E81]">
                      {emp.id}
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-semibold text-[#1E1B4B]">{emp.name}</p>
                      <p className="text-xs text-slate-500">
                        {emp.department} · A/C XXXX-{emp.bankAccountLast4}
                      </p>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatINR(emp.basicSalary)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatINR(allowances)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-[#1E1B4B]">
                      {formatINR(gross)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-rose-600">
                      -{formatINR(deductions)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-[#1E1B4B]">
                      {formatINR(net)}
                    </td>
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => onTogglePaymentStatus(emp.id)}
                        title="Toggle payment status"
                        className="inline-flex items-center gap-1.5 text-xs font-semibold hover:underline whitespace-nowrap shrink-0"
                      >
                        {emp.paymentStatus === 'Paid' ? (
                          <span className="inline-flex items-center gap-1.5 text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Paid
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-amber-700">
                            <Clock className="w-3.5 h-3.5" />
                            Pending
                          </span>
                        )}
                      </button>
                    </td>
                    <td className="py-3 px-5 text-right">
                      <button
                        type="button"
                        onClick={() => onOpenPaySlip(emp)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#E6EEFF] border border-[#CFE0FF] px-3 py-1 text-xs font-semibold text-[#2E5AAC] hover:bg-[#D6E4FF] transition-colors whitespace-nowrap shrink-0"
                      >
                        <ReceiptIndianRupee className="w-3.5 h-3.5" />
                        Pay Slip
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {employees.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-[#DFDDFA] bg-[#F5F4FF] text-sm font-bold text-[#1E1B4B]">
                  <td className="py-3.5 px-5" colSpan={2}>
                    Total ({employees.length} Employees)
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                    {formatINR(totals.basic)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                    {formatINR(totals.allowances)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                    {formatINR(totals.gross)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums text-rose-600">
                    -{formatINR(totals.deductions)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums text-[#4F46E5]">
                    {formatINR(totals.net)}
                  </td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
