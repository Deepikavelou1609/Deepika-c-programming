import React from 'react';
import { motion } from 'motion/react';
import { X, Printer, CheckCircle2 } from 'lucide-react';
import { Employee } from '../types/payroll';
import {
  calculateDeductions,
  calculateGrossSalary,
  calculateNetSalary,
  formatINR,
  numberToWordsINR,
} from '../utils/payrollCalc';

interface PaySlipModalProps {
  employee: Employee | null;
  monthLabel: string;
  onClose: () => void;
  onMarkPaid: (id: string) => void;
}

export const PaySlipModal: React.FC<PaySlipModalProps> = ({
  employee,
  monthLabel,
  onClose,
  onMarkPaid,
}) => {
  if (!employee) return null;

  const gross = calculateGrossSalary(employee);
  const totalDeductions = calculateDeductions(employee);
  const net = calculateNetSalary(employee);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1E1B4B]/40 backdrop-blur-xs p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="payslip-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className="print-only-slip w-full max-w-2xl rounded-2xl bg-white border border-[#DDDDFB] shadow-2xl overflow-hidden my-6"
      >
        <div className="flex items-center justify-between px-6 py-4 bg-[#F6F5FF] border-b border-[#E5E4FA] no-print">
          <h2 id="payslip-title" className="text-base font-bold text-[#1E1B4B]">
            Employee Details &amp; Salary Pay Slip
          </h2>
          <div className="flex items-center gap-2">
            {employee.paymentStatus === 'Pending' && (
              <button
                type="button"
                onClick={() => onMarkPaid(employee.id)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors whitespace-nowrap shrink-0"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Mark Paid
              </button>
            )}
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-3 py-1.5 text-xs font-semibold text-white hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close pay slip"
              className="p-1.5 rounded-lg text-slate-400 hover:text-[#1E1B4B] hover:bg-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 pb-5 border-b border-[#EFEFFE]">
            <div>
              <h3 className="text-xl font-bold tracking-tight text-[#1E1B4B]">
                Employee Payroll &amp; Salary System
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Official Monthly Salary Statement
              </p>
            </div>
            <div className="sm:text-right">
              <p className="text-xs text-slate-500">Pay Period</p>
              <p className="text-base font-bold text-[#1E1B4B]">{monthLabel}</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Status:{' '}
                <span
                  className={
                    employee.paymentStatus === 'Paid'
                      ? 'text-emerald-700 font-semibold'
                      : 'text-amber-700 font-semibold'
                  }
                >
                  {employee.paymentStatus}
                </span>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-3 gap-x-6 text-sm">
            <div>
              <p className="text-xs text-slate-500">Employee Name</p>
              <p className="font-semibold text-[#1E1B4B]">{employee.name}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Employee ID</p>
              <p className="font-mono tabular-nums font-semibold text-[#4F46E5]">
                {employee.id}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Department</p>
              <p className="font-medium text-[#1E1B4B]">{employee.department}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Designation</p>
              <p className="font-medium text-[#1E1B4B]">{employee.designation}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Date of Joining</p>
              <p className="font-mono tabular-nums text-[#1E1B4B]">{employee.joinDate}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Bank Account</p>
              <p className="font-mono tabular-nums text-[#1E1B4B]">
                XXXX-{employee.bankAccountLast4}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div className="border border-[#E4E3FA] rounded-xl overflow-hidden">
              <div className="bg-[#ECEBFF] px-4 py-2.5 border-b border-[#DFDDFA] flex items-center justify-between">
                <span className="text-xs font-semibold text-[#1E1B4B]">Earnings</span>
                <span className="text-xs font-semibold text-[#1E1B4B]">Amount</span>
              </div>
              <div className="divide-y divide-[#F3F2FF] text-sm">
                <div className="px-4 py-2.5 flex justify-between">
                  <span className="text-slate-600">Basic Salary</span>
                  <span className="font-mono tabular-nums text-[#1E1B4B]">
                    {formatINR(employee.basicSalary)}
                  </span>
                </div>
                <div className="px-4 py-2.5 flex justify-between">
                  <span className="text-slate-600">House Rent Allowance (HRA)</span>
                  <span className="font-mono tabular-nums text-[#1E1B4B]">
                    {formatINR(employee.hra)}
                  </span>
                </div>
                <div className="px-4 py-2.5 flex justify-between">
                  <span className="text-slate-600">Dearness Allowance (DA)</span>
                  <span className="font-mono tabular-nums text-[#1E1B4B]">
                    {formatINR(employee.da)}
                  </span>
                </div>
                <div className="px-4 py-2.5 flex justify-between">
                  <span className="text-slate-600">Other Allowances</span>
                  <span className="font-mono tabular-nums text-[#1E1B4B]">
                    {formatINR(employee.otherAllowances)}
                  </span>
                </div>
                <div className="px-4 py-2.5 flex justify-between bg-[#F7F6FF] font-bold">
                  <span className="text-[#1E1B4B]">Gross Salary</span>
                  <span className="font-mono tabular-nums text-[#1E1B4B]">
                    {formatINR(gross)}
                  </span>
                </div>
              </div>
            </div>

            <div className="border border-[#E4E3FA] rounded-xl overflow-hidden flex flex-col justify-between">
              <div>
                <div className="bg-[#ECEBFF] px-4 py-2.5 border-b border-[#DFDDFA] flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#1E1B4B]">Deductions</span>
                  <span className="text-xs font-semibold text-[#1E1B4B]">Amount</span>
                </div>
                <div className="divide-y divide-[#F3F2FF] text-sm">
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-600">Provident Fund (PF)</span>
                    <span className="font-mono tabular-nums text-[#1E1B4B]">
                      {formatINR(employee.pfDeduction)}
                    </span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-600">Income Tax (TDS)</span>
                    <span className="font-mono tabular-nums text-[#1E1B4B]">
                      {formatINR(employee.taxDeduction)}
                    </span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-600">Professional Tax / Other</span>
                    <span className="font-mono tabular-nums text-[#1E1B4B]">
                      {formatINR(employee.otherDeductions)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="px-4 py-2.5 flex justify-between bg-[#F7F6FF] border-t border-[#E4E3FA] text-sm font-bold">
                <span className="text-[#1E1B4B]">Total Deductions</span>
                <span className="font-mono tabular-nums text-rose-600">
                  {formatINR(totalDeductions)}
                </span>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-gradient-to-r from-[#5B52E5] to-[#4338CA] text-white px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <p className="text-xs text-indigo-100">Net Payable Salary</p>
              <p className="text-xs text-indigo-100 mt-0.5">{numberToWordsINR(net)}</p>
            </div>
            <p className="text-2xl font-bold font-mono tabular-nums text-white">
              {formatINR(net)}
            </p>
          </div>

          <p className="text-xs text-slate-400 text-center">
            System-generated salary statement · Net Salary = Gross Salary ({formatINR(gross)}) −
            Total Deductions ({formatINR(totalDeductions)})
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};
