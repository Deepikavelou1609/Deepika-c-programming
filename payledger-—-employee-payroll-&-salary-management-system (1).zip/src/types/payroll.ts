export type Department =
  | 'CSE Cyber Security'
  | 'IT'
  | 'ECE'
  | 'CSE'
  | 'AI & DS'
  | 'Engineering'
  | 'Finance'
  | 'Human Resources';

export type PaymentStatus = 'Paid' | 'Pending';

export type NavSection =
  | 'home'
  | 'employees'
  | 'calculate'
  | 'payroll'
  | 'settings';

export interface Employee {
  id: string;
  name: string;
  department: Department;
  designation: string;
  email: string;
  joinDate: string;
  basicSalary: number;
  hra: number;
  da: number;
  otherAllowances: number;
  pfDeduction: number;
  taxDeduction: number;
  otherDeductions: number;
  paymentStatus: PaymentStatus;
  lastPaidMonth: string;
  bankAccountLast4: string;
}

export interface PayrollLogEntry {
  id: string;
  timestamp: string;
  action: string;
  details: string;
}

export const DEPARTMENTS: Department[] = [
  'CSE Cyber Security',
  'IT',
  'ECE',
  'CSE',
  'AI & DS',
  'Engineering',
  'Finance',
  'Human Resources',
];

export const PAYROLL_MONTHS = [
  { value: '2026-11', label: 'Nov 2026', fullLabel: 'November 2026' },
  { value: '2026-10', label: 'Oct 2026', fullLabel: 'October 2026' },
  { value: '2026-09', label: 'Sep 2026', fullLabel: 'September 2026' },
];
