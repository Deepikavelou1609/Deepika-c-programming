import { Employee } from '../types/payroll';

export function calculateAllowances(emp: Pick<Employee, 'hra' | 'da' | 'otherAllowances'>): number {
  return emp.hra + emp.da + emp.otherAllowances;
}

export function calculateGrossSalary(
  emp: Pick<Employee, 'basicSalary' | 'hra' | 'da' | 'otherAllowances'>
): number {
  return emp.basicSalary + calculateAllowances(emp);
}

export function calculateDeductions(
  emp: Pick<Employee, 'pfDeduction' | 'taxDeduction' | 'otherDeductions'>
): number {
  return emp.pfDeduction + emp.taxDeduction + emp.otherDeductions;
}

export function calculateNetSalary(
  emp: Pick<
    Employee,
    'basicSalary' | 'hra' | 'da' | 'otherAllowances' | 'pfDeduction' | 'taxDeduction' | 'otherDeductions'
  >
): number {
  const gross = calculateGrossSalary(emp);
  const deductions = calculateDeductions(emp);
  return Math.max(0, gross - deductions);
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(Math.round(amount));
}

export function computeStandardComponents(basicSalary: number) {
  const hra = Math.round(basicSalary * 0.2);
  const da = Math.round(basicSalary * 0.1);
  const otherAllowances = basicSalary > 0 ? 2500 : 0;
  const gross = basicSalary + hra + da + otherAllowances;
  const pfDeduction = Math.round(basicSalary * 0.12);
  const taxDeduction = gross > 50000 ? Math.round((gross - 50000) * 0.1) : Math.round(gross * 0.03);
  const otherDeductions = basicSalary > 0 ? 200 : 0;
  return {
    hra,
    da,
    otherAllowances,
    pfDeduction,
    taxDeduction,
    otherDeductions,
  };
}

export function numberToWordsINR(num: number): string {
  const n = Math.round(num);
  if (n === 0) return 'Zero Rupees Only';

  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen',
  ];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const twoDigits = (val: number): string => {
    if (val < 20) return ones[val];
    return tens[Math.floor(val / 10)] + (val % 10 ? ' ' + ones[val % 10] : '');
  };

  const threeDigits = (val: number): string => {
    if (val === 0) return '';
    if (val < 100) return twoDigits(val);
    return ones[Math.floor(val / 100)] + ' Hundred' + (val % 100 ? ' ' + twoDigits(val % 100) : '');
  };

  let remaining = n;
  const parts: string[] = [];

  const crore = Math.floor(remaining / 10000000);
  if (crore > 0) {
    parts.push(twoDigits(crore) + ' Crore');
    remaining %= 10000000;
  }

  const lakh = Math.floor(remaining / 100000);
  if (lakh > 0) {
    parts.push(twoDigits(lakh) + ' Lakh');
    remaining %= 100000;
  }

  const thousand = Math.floor(remaining / 1000);
  if (thousand > 0) {
    parts.push(twoDigits(thousand) + ' Thousand');
    remaining %= 1000;
  }

  if (remaining > 0) {
    parts.push(threeDigits(remaining));
  }

  return parts.join(' ') + ' Rupees Only';
}

export function exportPayrollCSV(employees: Employee[], monthLabel: string): void {
  const headers = [
    'Employee ID',
    'Name',
    'Department',
    'Designation',
    'Basic Salary',
    'HRA',
    'DA',
    'Other Allowances',
    'Total Allowances',
    'Gross Salary',
    'PF Deduction',
    'Tax Deduction',
    'Other Deductions',
    'Total Deductions',
    'Net Salary',
    'Payment Status',
    'Pay Period',
  ];

  const rows = employees.map((emp) => {
    const allowances = calculateAllowances(emp);
    const gross = calculateGrossSalary(emp);
    const deductions = calculateDeductions(emp);
    const net = calculateNetSalary(emp);
    return [
      emp.id,
      `"${emp.name.replace(/"/g, '""')}"`,
      `"${emp.department}"`,
      `"${emp.designation.replace(/"/g, '""')}"`,
      emp.basicSalary,
      emp.hra,
      emp.da,
      emp.otherAllowances,
      allowances,
      gross,
      emp.pfDeduction,
      emp.taxDeduction,
      emp.otherDeductions,
      deductions,
      net,
      emp.paymentStatus,
      `"${monthLabel}"`,
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `payroll_report_${monthLabel.toLowerCase().replace(/\s+/g, '_')}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportRecordsJSON(employees: Employee[]): void {
  const payload = {
    exportedAt: new Date().toISOString(),
    schema: 'EmployeeRecord_v1',
    recordCount: employees.length,
    employees,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `employee_records_backup_${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
