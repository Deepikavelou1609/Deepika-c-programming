import { useState, useEffect } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { Menu, UserPlus } from 'lucide-react';
import {
  Employee,
  NavSection,
  PAYROLL_MONTHS,
  PayrollLogEntry,
} from './types/payroll';
import { SEED_EMPLOYEES, SEED_LOGS } from './data/seedEmployees';
import {
  calculateNetSalary,
  exportPayrollCSV,
  exportRecordsJSON,
  formatINR,
} from './utils/payrollCalc';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { EmployeesView } from './components/EmployeesView';
import { CalculateSalaryView } from './components/CalculateSalaryView';
import { PayrollView } from './components/PayrollView';
import { BackupProjectView } from './components/BackupProjectView';
import { EmployeeModal } from './components/EmployeeModal';
import { PaySlipModal } from './components/PaySlipModal';
import { ConfirmDeleteModal } from './components/ConfirmDeleteModal';

const STORAGE_EMPLOYEES_KEY = 'payledger_employees_v2';
const STORAGE_LOGS_KEY = 'payledger_logs_v2';
const STORAGE_AUTH_KEY = 'payledger_auth_v1';

const SECTION_LABELS: Record<NavSection, string> = {
  home: 'Home',
  employees: 'View Employees',
  calculate: 'Calculate Salary',
  payroll: 'Payroll Report',
  settings: 'Settings',
};

function getTimestamp(): string {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd} ${hh}:${min}`;
}

export default function App() {
  const [authSession, setAuthSession] = useState<{ username: string; role: string } | null>(() => {
    try {
      const saved = sessionStorage.getItem(STORAGE_AUTH_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore storage error
    }
    return null;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_EMPLOYEES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Fallback to seed dataset
    }
    return SEED_EMPLOYEES;
  });

  const [logs, setLogs] = useState<PayrollLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LOGS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Fallback to seed logs
    }
    return SEED_LOGS;
  });

  const [activeSection, setActiveSection] = useState<NavSection>('home');
  const [selectedMonth, setSelectedMonth] = useState<string>(PAYROLL_MONTHS[0].value);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [employeeModalOpen, setEmployeeModalOpen] = useState(false);
  const [employeeModalMode, setEmployeeModalMode] = useState<'add' | 'edit'>('add');
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [slipEmployee, setSlipEmployee] = useState<Employee | null>(null);
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_EMPLOYEES_KEY, JSON.stringify(employees));
    } catch {
      // Ignore storage quota errors
    }
  }, [employees]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LOGS_KEY, JSON.stringify(logs));
    } catch {
      // Ignore storage quota errors
    }
  }, [logs]);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const handleLoginSuccess = (username: string, role: string) => {
    const session = { username, role };
    setAuthSession(session);
    setActiveSection('home');
    try {
      sessionStorage.setItem(STORAGE_AUTH_KEY, JSON.stringify(session));
    } catch {
      // Ignore
    }
  };

  const handleLogout = () => {
    setAuthSession(null);
    setEmployeeModalOpen(false);
    setSlipEmployee(null);
    setDeletingEmployee(null);
    try {
      sessionStorage.removeItem(STORAGE_AUTH_KEY);
    } catch {
      // Ignore
    }
  };

  const appendLog = (action: string, details: string) => {
    setLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: getTimestamp(),
        action,
        details,
      },
      ...prev.slice(0, 19),
    ]);
  };

  const currentMonthObj =
    PAYROLL_MONTHS.find((m) => m.value === selectedMonth) || PAYROLL_MONTHS[0];

  const openAddModal = () => {
    setEmployeeModalMode('add');
    setEditingEmployee(null);
    setEmployeeModalOpen(true);
  };

  const openEditModal = (employee: Employee) => {
    setEmployeeModalMode('edit');
    setEditingEmployee(employee);
    setEmployeeModalOpen(true);
  };

  const handleSaveEmployee = (record: Employee) => {
    if (employeeModalMode === 'add') {
      setEmployees((prev) => [...prev, record]);
      appendLog('Employee Added', `Added ${record.name} (${record.id}) in ${record.department}.`);
      setToastMessage(`Added ${record.name} (${record.id}).`);
    } else {
      setEmployees((prev) => prev.map((e) => (e.id === record.id ? record : e)));
      appendLog('Record Updated', `Updated salary record for ${record.name} (${record.id}).`);
      setToastMessage(`Updated record for ${record.name}.`);
    }
    setEmployeeModalOpen(false);
  };

  const handleQuickUpdateSalary = (
    id: string,
    basic: number,
    allowancesTotal: number,
    deductionsTotal: number
  ) => {
    const target = employees.find((e) => e.id === id);
    if (!target) return;

    const hra = Math.round(allowancesTotal * 0.6);
    const da = Math.round(allowancesTotal * 0.3);
    const otherAllowances = Math.max(0, allowancesTotal - hra - da);

    const pfDeduction = Math.round(deductionsTotal * 0.75);
    const taxDeduction = Math.round(deductionsTotal * 0.15);
    const otherDeductions = Math.max(0, deductionsTotal - pfDeduction - taxDeduction);

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === id
          ? {
              ...e,
              basicSalary: basic,
              hra,
              da,
              otherAllowances,
              pfDeduction,
              taxDeduction,
              otherDeductions,
            }
          : e
      )
    );
    appendLog('Salary Calculated', `Updated ${target.name} (${target.id}) salary figures.`);
  };

  const handleUpdateFullEmployeeSalary = (updated: Employee) => {
    setEmployees((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
    appendLog('Salary Updated', `Updated itemized salary for ${updated.name} (${updated.id}).`);
    setToastMessage(`Saved salary calculation for ${updated.name}.`);
  };

  const handleDeleteEmployee = (id: string) => {
    const target = employees.find((e) => e.id === id);
    setEmployees((prev) => prev.filter((e) => e.id !== id));
    if (target) {
      appendLog('Record Deleted', `Removed ${target.name} (${target.id}).`);
      setToastMessage(`Deleted ${target.name} from records.`);
    }
    setDeletingEmployee(null);
  };

  const handleMarkPaid = (id: string) => {
    const target = employees.find((e) => e.id === id);
    if (!target) return;
    setEmployees((prev) =>
      prev.map((e) =>
        e.id === id
          ? { ...e, paymentStatus: 'Paid', lastPaidMonth: selectedMonth }
          : e
      )
    );
    if (slipEmployee?.id === id) {
      setSlipEmployee({ ...target, paymentStatus: 'Paid', lastPaidMonth: selectedMonth });
    }
    appendLog(
      'Salary Disbursed',
      `Marked ${target.name} (${target.id}) Paid (${formatINR(calculateNetSalary(target))}).`
    );
    setToastMessage(`Marked ${target.name} as Paid.`);
  };

  const handleTogglePaymentStatus = (id: string) => {
    const target = employees.find((e) => e.id === id);
    if (!target) return;
    const nextStatus = target.paymentStatus === 'Paid' ? 'Pending' : 'Paid';
    setEmployees((prev) =>
      prev.map((e) =>
        e.id === id
          ? {
              ...e,
              paymentStatus: nextStatus,
              lastPaidMonth: nextStatus === 'Paid' ? selectedMonth : e.lastPaidMonth,
            }
          : e
      )
    );
    setToastMessage(`${target.name} status set to ${nextStatus}.`);
  };

  const handleProcessAllPending = () => {
    const pendingList = employees.filter((e) => e.paymentStatus === 'Pending');
    if (pendingList.length === 0) return;
    const totalPendingNet = pendingList.reduce((sum, e) => sum + calculateNetSalary(e), 0);

    setEmployees((prev) =>
      prev.map((e) =>
        e.paymentStatus === 'Pending'
          ? { ...e, paymentStatus: 'Paid', lastPaidMonth: selectedMonth }
          : e
      )
    );
    appendLog(
      'Batch Payroll Processed',
      `Disbursed ${currentMonthObj.fullLabel} salaries for ${pendingList.length} employees (${formatINR(
        totalPendingNet
      )} net).`
    );
    setToastMessage(
      `Processed ${pendingList.length} pending salaries for ${currentMonthObj.fullLabel}.`
    );
  };

  const handleExportCSV = () => {
    exportPayrollCSV(employees, currentMonthObj.fullLabel);
    appendLog('CSV Exported', `Exported ${employees.length} payroll rows.`);
    setToastMessage('Payroll CSV downloaded.');
  };

  const handleExportJSON = () => {
    exportRecordsJSON(employees);
    appendLog('Backup Created', `Downloaded JSON backup for ${employees.length} records.`);
    setToastMessage('JSON backup downloaded.');
  };

  const handleRestoreJSON = (imported: Employee[]) => {
    setEmployees(imported);
    appendLog('Backup Restored', `Restored ${imported.length} employee records from JSON.`);
    setToastMessage(`Restored ${imported.length} records.`);
  };

  const handleResetSampleData = () => {
    setEmployees(SEED_EMPLOYEES);
    setLogs(SEED_LOGS);
    setToastMessage('Reset to sample dataset.');
  };

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence mode="wait">
        {!authSession ? (
          <motion.div
            key="login-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <LoginPage onLoginSuccess={handleLoginSuccess} />
          </motion.div>
        ) : (
          <motion.div
            key="workspace-shell"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="min-h-screen flex bg-[#F3F2FF] text-[#1E1B4B]"
          >
            <Sidebar
              activeSection={activeSection}
              onSelectSection={setActiveSection}
              onAddEmployee={openAddModal}
              onLogout={handleLogout}
              mobileOpen={mobileMenuOpen}
              onCloseMobile={() => setMobileMenuOpen(false)}
            />

            <div className="flex-1 flex flex-col min-w-0">
              {/* Clean pastel top bar */}
              <header className="sticky top-0 z-30 bg-[#F7F6FF]/90 backdrop-blur-md border-b border-[#E4E3FA] px-4 sm:px-7 h-14 flex items-center justify-between gap-8 no-print">
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    type="button"
                    onClick={() => setMobileMenuOpen(true)}
                    aria-label="Open navigation menu"
                    className="lg:hidden p-2 -ml-2 rounded-lg text-[#312E81] hover:bg-[#ECEBFF]"
                  >
                    <Menu className="w-5 h-5" />
                  </button>
                  <div className="flex items-center gap-2 text-sm truncate">
                    <span className="font-semibold text-[#5B52E5]">Payroll System</span>
                    <span className="text-indigo-200" aria-hidden="true">
                      /
                    </span>
                    <span className="font-semibold text-[#1E1B4B] truncate">
                      {SECTION_LABELS[activeSection]}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <motion.button
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.98 }}
                    type="button"
                    onClick={openAddModal}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#7B74F2] to-[#5B52E5] px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:from-[#6C64EC] hover:to-[#4F46E5] transition-all whitespace-nowrap shrink-0"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    Add Employee
                  </motion.button>
                </div>
              </header>

              <main className="flex-1 p-4 sm:p-7 max-w-7xl w-full mx-auto no-print">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeSection}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                  >
                    {activeSection === 'home' && (
                      <DashboardView
                        employees={employees}
                        username={authSession.username}
                        selectedMonthShortLabel={currentMonthObj.label}
                        onNavigate={setActiveSection}
                        onEditEmployee={openEditModal}
                        onDeleteEmployee={setDeletingEmployee}
                        onOpenPaySlip={setSlipEmployee}
                        onQuickUpdateSalary={handleQuickUpdateSalary}
                      />
                    )}

                    {activeSection === 'employees' && (
                      <EmployeesView
                        employees={employees}
                        onAddEmployee={openAddModal}
                        onEditEmployee={openEditModal}
                        onDeleteEmployee={setDeletingEmployee}
                        onOpenPaySlip={setSlipEmployee}
                      />
                    )}

                    {activeSection === 'calculate' && (
                      <CalculateSalaryView
                        employees={employees}
                        onUpdateEmployeeSalary={handleUpdateFullEmployeeSalary}
                        onOpenPaySlip={setSlipEmployee}
                      />
                    )}

                    {activeSection === 'payroll' && (
                      <PayrollView
                        employees={employees}
                        selectedMonth={selectedMonth}
                        onChangeMonth={setSelectedMonth}
                        onProcessAllPending={handleProcessAllPending}
                        onTogglePaymentStatus={handleTogglePaymentStatus}
                        onOpenPaySlip={setSlipEmployee}
                        onExportCSV={handleExportCSV}
                      />
                    )}

                    {activeSection === 'settings' && (
                      <BackupProjectView
                        employees={employees}
                        onExportJSON={handleExportJSON}
                        onExportCSV={handleExportCSV}
                        onRestoreJSON={handleRestoreJSON}
                        onResetSampleData={handleResetSampleData}
                      />
                    )}
                  </motion.div>
                </AnimatePresence>
              </main>
            </div>

            <AnimatePresence>
              {toastMessage && (
                <motion.div
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 16 }}
                  transition={{ duration: 0.2 }}
                  role="status"
                  aria-live="polite"
                  className="fixed bottom-5 right-5 z-50 rounded-xl bg-[#1E1B4B] text-white px-4 py-2.5 text-sm font-medium shadow-lg no-print"
                >
                  {toastMessage}
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {employeeModalOpen && (
                <EmployeeModal
                  isOpen={employeeModalOpen}
                  mode={employeeModalMode}
                  initialEmployee={editingEmployee}
                  existingIds={employees.map((e) => e.id)}
                  onClose={() => setEmployeeModalOpen(false)}
                  onSave={handleSaveEmployee}
                />
              )}
            </AnimatePresence>

            <AnimatePresence>
              {slipEmployee && (
                <PaySlipModal
                  employee={slipEmployee}
                  monthLabel={currentMonthObj.fullLabel}
                  onClose={() => setSlipEmployee(null)}
                  onMarkPaid={handleMarkPaid}
                />
              )}
            </AnimatePresence>

            <AnimatePresence>
              {deletingEmployee && (
                <ConfirmDeleteModal
                  employee={deletingEmployee}
                  onCancel={() => setDeletingEmployee(null)}
                  onConfirm={handleDeleteEmployee}
                />
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  );
}
